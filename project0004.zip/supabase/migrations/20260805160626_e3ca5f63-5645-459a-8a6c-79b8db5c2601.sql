do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig, p.proname
    from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public' and p.prosecdef
  loop
    execute format('revoke all on function %s from public, anon, authenticated', f.sig);
    if f.proname like 'app\_%' or f.proname in ('claim_account','has_role') then
      execute format('grant execute on function %s to authenticated', f.sig);
    end if;
    execute format('grant execute on function %s to service_role', f.sig);
  end loop;
end $$;

-- internal-only: app_close_expired_sessions is invoked by the scheduler, not the app
revoke all on function public.app_close_expired_sessions() from authenticated;

create extension if not exists pg_cron;
select cron.schedule('attendx-close-expired-sessions', '* * * * *',
  $$select public.app_close_expired_sessions();$$);