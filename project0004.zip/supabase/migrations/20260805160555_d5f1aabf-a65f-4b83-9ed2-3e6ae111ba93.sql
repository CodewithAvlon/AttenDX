-- ---------- student flow ----------
create or replace function public.recompute_bench(p_session uuid, p_bench int)
returns void language plpgsql volatile security definer set search_path = public as $$
declare v_total int; v_ok int; cur public.bench_status; slot record;
begin
  select status into cur from public.session_benches where session_id = p_session and bench_number = p_bench;
  if cur = 'EMPTY' then return; end if;
  select count(*), count(*) filter (where verified) into v_total, v_ok
    from public.session_slots where session_id = p_session and bench_number = p_bench;
  if v_total = 0 then return; end if;
  if v_ok = v_total then
    update public.session_benches set status = 'PRESENT' where session_id = p_session and bench_number = p_bench;
    for slot in select * from public.session_slots where session_id = p_session and bench_number = p_bench loop
      perform public.finalize_attendance(p_session, slot.roll_number, slot.name, p_bench, 'PRESENT', true);
    end loop;
  elsif v_ok > 0 then
    update public.session_benches set status = 'PARTIAL' where session_id = p_session and bench_number = p_bench;
  end if;
end $$;
revoke execute on function public.recompute_bench(uuid, int) from anon, authenticated;

create or replace function public.app_student_session()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare st public.students; s public.sessions; me public.session_slots; v jsonb;
begin
  select * into st from public.students where user_id = auth.uid();
  if not found then raise exception 'Not registered as a student'; end if;
  select * into s from public.sessions where class_id = st.class_id and active
    order by started_at desc limit 1;
  if not found then return jsonb_build_object('active', false); end if;
  select * into me from public.session_slots where session_id = s.id and roll_number = st.roll_number;

  v := jsonb_build_object(
    'active', true,
    'sessionId', s.id,
    'subject', s.subject,
    'className', s.class_name,
    'teacherName', s.teacher_name,
    'totalBenches', s.total_benches,
    'myBench', st.bench_number,
    'mySeat', st.seat,
    'remainingSeconds', greatest(0, s.duration_seconds - floor(extract(epoch from (now() - s.started_at)))::int),
    'benchStatus', (select status from public.session_benches where session_id = s.id and bench_number = st.bench_number),
    'seated', me.roll_number is not null
  );
  if me.roll_number is not null then
    v := v || jsonb_build_object(
      'method', me.method, 'myCode', me.code, 'entered', me.entered,
      'verified', me.verified, 'failedAttempts', me.failed_attempts,
      'attemptsLeft', greatest(0, 5 - me.failed_attempts),
      'locked', me.failed_attempts >= 5 and not me.verified,
      'partnerName', (select sl.name from public.session_slots sl
        where sl.session_id = s.id and sl.bench_number = st.bench_number and sl.roll_number <> st.roll_number limit 1),
      'partnerVerified', coalesce((select sl.verified from public.session_slots sl
        where sl.session_id = s.id and sl.bench_number = st.bench_number and sl.roll_number <> st.roll_number limit 1), false),
      'status', (select status::text from public.attendance_records
        where session_id = s.id and roll_number = st.roll_number)
    );
  end if;
  return v;
end $$;
revoke execute on function public.app_student_session() from anon;

create or replace function public.app_check_in(p_bench int)
returns jsonb language plpgsql volatile security definer set search_path = public as $$
declare st public.students; s public.sessions;
begin
  select * into st from public.students where user_id = auth.uid();
  if not found then raise exception 'Not registered as a student'; end if;
  select * into s from public.sessions where class_id = st.class_id and active order by started_at desc limit 1;
  if not found then raise exception 'No attendance session is running for your class'; end if;
  if p_bench <> st.bench_number then
    raise exception 'Bench % is not your assigned bench (yours is %)', p_bench, st.bench_number;
  end if;
  update public.session_slots set entered = true where session_id = s.id and roll_number = st.roll_number;
  if not found then raise exception 'You are not seated in this session'; end if;
  perform public.log_activity(st.name || ' checked in at bench ' || p_bench);
  return public.app_student_session();
end $$;
revoke execute on function public.app_check_in(int) from anon;

create or replace function public.app_verify_partner(p_code text)
returns jsonb language plpgsql volatile security definer set search_path = public as $$
declare
  st public.students; s public.sessions; me public.session_slots; partner public.session_slots;
  v_expected text; v_input text := upper(regexp_replace(coalesce(p_code,''), '\s', '', 'g'));
begin
  select * into st from public.students where user_id = auth.uid();
  if not found then raise exception 'Not registered as a student'; end if;
  select * into s from public.sessions where class_id = st.class_id and active order by started_at desc limit 1;
  if not found then raise exception 'No attendance session is running for your class'; end if;

  select * into me from public.session_slots where session_id = s.id and roll_number = st.roll_number for update;
  if not found then raise exception 'You are not seated in this session'; end if;
  if not me.entered then raise exception 'Tap your bench to check in first'; end if;
  if me.verified then return public.app_student_session(); end if;
  if me.failed_attempts >= 5 then
    raise exception 'Too many incorrect attempts. Ask your teacher to verify you manually.';
  end if;

  select * into partner from public.session_slots
    where session_id = s.id and bench_number = me.bench_number and roll_number <> me.roll_number limit 1;
  v_expected := coalesce(partner.code, me.code);

  if v_input <> v_expected then
    update public.session_slots set failed_attempts = failed_attempts + 1
      where session_id = s.id and roll_number = me.roll_number;
    perform public.log_activity('Failed verification by ' || st.name || ' (bench ' || me.bench_number || ')');
    return public.app_student_session() || jsonb_build_object('lastResult', 'INCORRECT');
  end if;

  update public.session_slots set verified = true, failed_attempts = 0
    where session_id = s.id and roll_number = me.roll_number;
  perform public.recompute_bench(s.id, me.bench_number);
  perform public.log_activity(st.name || ' verified at bench ' || me.bench_number);
  return public.app_student_session() || jsonb_build_object('lastResult', 'VERIFIED');
end $$;
revoke execute on function public.app_verify_partner(text) from anon;

create or replace function public.app_my_history()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_roll text := public.my_roll();
begin
  if v_roll is null then raise exception 'Not registered as a student'; end if;
  return coalesce((
    select jsonb_agg(x order by x->>'date' desc) from (
      select jsonb_build_object('date', r.recorded_at, 'status', r.status,
        'subject', s.subject, 'className', s.class_name, 'benchNumber', r.bench_number) as x
      from public.attendance_records r join public.sessions s on s.id = r.session_id
      where r.roll_number = v_roll order by r.recorded_at desc limit 100
    ) t), '[]'::jsonb);
end $$;
revoke execute on function public.app_my_history() from anon;

-- ---------- teacher live view ----------
create or replace function public.app_session_view(p_session uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare s public.sessions; v_uid uuid := auth.uid();
begin
  if not (public.has_role(v_uid,'teacher') or public.has_role(v_uid,'admin') or public.has_role(v_uid,'principal')) then
    raise exception 'Not authorised';
  end if;
  select * into s from public.sessions where id = p_session;
  if not found then raise exception 'Unknown session'; end if;
  return jsonb_build_object(
    'sessionId', s.id, 'classId', s.class_id, 'className', s.class_name, 'subject', s.subject,
    'teacherName', s.teacher_name, 'totalBenches', s.total_benches, 'active', s.active,
    'startedAt', s.started_at, 'endedAt', s.ended_at,
    'remainingSeconds', case when s.active
      then greatest(0, s.duration_seconds - floor(extract(epoch from (now() - s.started_at)))::int) else 0 end,
    'layout', (select jsonb_build_object('rows', bl.grid_rows, 'cols', bl.grid_cols, 'cells', bl.cells)
               from public.bench_layouts bl where bl.class_id = s.class_id),
    'benches', coalesce((select jsonb_agg(jsonb_build_object(
        'benchNumber', b.bench_number, 'status', b.status,
        'students', coalesce((select jsonb_agg(jsonb_build_object(
            'rollNumber', sl.roll_number, 'name', sl.name, 'seat', sl.seat,
            'method', sl.method, 'entered', sl.entered, 'verified', sl.verified,
            'failedAttempts', sl.failed_attempts) order by sl.seat)
          from public.session_slots sl where sl.session_id = s.id and sl.bench_number = b.bench_number), '[]'::jsonb)
      ) order by b.bench_number) from public.session_benches b where b.session_id = s.id), '[]'::jsonb),
    'counts', (select jsonb_build_object(
        'present', count(*) filter (where status = 'PRESENT'),
        'late', count(*) filter (where status = 'LATE'),
        'absent', count(*) filter (where status = 'ABSENT'))
      from public.attendance_records where session_id = s.id),
    'seatedCount', (select count(*) from public.session_slots where session_id = s.id),
    'verifiedCount', (select count(*) from public.session_slots where session_id = s.id and verified)
  );
end $$;
revoke execute on function public.app_session_view(uuid) from anon;

create or replace function public.app_teacher_home()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v public.staff_accounts := public.require_staff('teacher');
begin
  return jsonb_build_object(
    'teacherName', v.display_name,
    'classes', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'name', c.name,
        'studentCount', (select count(*) from public.students st where st.class_id = c.id),
        'liveSessionId', (select id from public.sessions s where s.class_id = c.id and s.active limit 1))
      order by c.name) from public.classes c), '[]'::jsonb),
    'mySessions', coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'className', s.class_name,
        'subject', s.subject, 'active', s.active, 'startedAt', s.started_at,
        'present', (select count(*) from public.attendance_records r where r.session_id = s.id and r.status <> 'ABSENT'),
        'total', (select count(*) from public.session_slots sl where sl.session_id = s.id))
      order by s.started_at desc) from (select * from public.sessions where teacher_login = v.login_id
        order by started_at desc limit 20) s), '[]'::jsonb)
  );
end $$;
revoke execute on function public.app_teacher_home() from anon;

-- ---------- admin ----------
create or replace function public.app_admin_home()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.require_staff('admin');
  return jsonb_build_object(
    'classes', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'name', c.name,
        'studentCount', (select count(*) from public.students st where st.class_id = c.id),
        'layout', (select jsonb_build_object('rows', bl.grid_rows, 'cols', bl.grid_cols, 'cells', bl.cells)
                   from public.bench_layouts bl where bl.class_id = c.id))
      order by c.name) from public.classes c), '[]'::jsonb),
    'students', coalesce((select jsonb_agg(jsonb_build_object('rollNumber', st.roll_number, 'name', st.name,
        'classId', st.class_id, 'benchNumber', st.bench_number, 'seat', st.seat,
        'partnerRoll', st.partner_roll, 'registered', st.user_id is not null,
        'sessionsCounted', (select count(*) from public.attendance_records r where r.roll_number = st.roll_number),
        'presentCount', (select count(*) from public.attendance_records r
           where r.roll_number = st.roll_number and r.status <> 'ABSENT'))
      order by st.class_id, st.bench_number, st.seat) from public.students st), '[]'::jsonb),
    'staff', coalesce((select jsonb_agg(jsonb_build_object('loginId', sa.login_id, 'name', sa.display_name,
        'role', sa.role, 'registered', sa.user_id is not null) order by sa.role, sa.login_id)
      from public.staff_accounts sa), '[]'::jsonb),
    'sessions', coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'className', s.class_name,
        'subject', s.subject, 'teacherName', s.teacher_name, 'active', s.active, 'startedAt', s.started_at)
      order by s.started_at desc) from (select * from public.sessions order by started_at desc limit 30) s), '[]'::jsonb)
  );
end $$;
revoke execute on function public.app_admin_home() from anon;

create or replace function public.app_save_layout(p_class_id text, p_rows int, p_cols int, p_cells jsonb)
returns void language plpgsql volatile security definer set search_path = public as $$
begin
  perform public.require_staff('admin');
  if p_rows < 1 or p_rows > 12 or p_cols < 1 or p_cols > 12 then
    raise exception 'Grid must be between 1x1 and 12x12';
  end if;
  insert into public.bench_layouts (class_id, grid_rows, grid_cols, cells, updated_at)
  values (p_class_id, p_rows, p_cols, coalesce(p_cells, '[]'::jsonb), now())
  on conflict (class_id) do update set grid_rows = excluded.grid_rows, grid_cols = excluded.grid_cols,
    cells = excluded.cells, updated_at = now();
  perform public.log_activity('Room layout updated for ' || p_class_id);
end $$;
revoke execute on function public.app_save_layout(text, int, int, jsonb) from anon;

create or replace function public.app_upsert_student(
  p_roll text, p_name text, p_class_id text, p_bench int, p_seat text, p_partner text)
returns void language plpgsql volatile security definer set search_path = public as $$
declare v_roll text := upper(trim(coalesce(p_roll,''))); v_seat text := upper(trim(coalesce(p_seat,'')));
begin
  perform public.require_staff('admin');
  if v_roll = '' or coalesce(trim(p_name),'') = '' then raise exception 'Roll number and name are required'; end if;
  if v_seat not in ('A','B') then raise exception 'Seat must be A or B'; end if;
  if p_bench < 1 or p_bench > 60 then raise exception 'Bench number must be between 1 and 60'; end if;
  if not exists (select 1 from public.classes where id = p_class_id) then raise exception 'Unknown class'; end if;
  insert into public.students (roll_number, name, class_id, bench_number, seat, partner_roll)
  values (v_roll, trim(p_name), p_class_id, p_bench, v_seat, nullif(upper(trim(coalesce(p_partner,''))),''))
  on conflict (roll_number) do update set name = excluded.name, class_id = excluded.class_id,
    bench_number = excluded.bench_number, seat = excluded.seat, partner_roll = excluded.partner_roll;
  perform public.log_activity('Student saved: ' || v_roll);
end $$;
revoke execute on function public.app_upsert_student(text, text, text, int, text, text) from anon;

create or replace function public.app_delete_student(p_roll text)
returns void language plpgsql volatile security definer set search_path = public as $$
begin
  perform public.require_staff('admin');
  delete from public.students where lower(roll_number) = lower(trim(p_roll));
  perform public.log_activity('Student removed: ' || p_roll);
end $$;
revoke execute on function public.app_delete_student(text) from anon;

create or replace function public.app_upsert_staff(p_login text, p_name text, p_role text)
returns void language plpgsql volatile security definer set search_path = public as $$
declare v_role public.app_role; v_login text := trim(coalesce(p_login,''));
begin
  perform public.require_staff('admin');
  if v_login = '' or coalesce(trim(p_name),'') = '' then raise exception 'ID and name are required'; end if;
  if lower(coalesce(p_role,'')) not in ('teacher','admin','principal') then
    raise exception 'Role must be teacher, admin, or principal';
  end if;
  v_role := lower(p_role)::public.app_role;
  insert into public.staff_accounts (login_id, display_name, role)
  values (v_login, trim(p_name), v_role)
  on conflict (login_id) do update set display_name = excluded.display_name, role = excluded.role;
  perform public.log_activity('Staff saved: ' || v_login);
end $$;
revoke execute on function public.app_upsert_staff(text, text, text) from anon;

create or replace function public.app_delete_staff(p_login text)
returns void language plpgsql volatile security definer set search_path = public as $$
begin
  perform public.require_staff('admin');
  if lower(trim(p_login)) = 'admin' then raise exception 'The primary admin account cannot be removed'; end if;
  delete from public.staff_accounts where lower(login_id) = lower(trim(p_login));
  perform public.log_activity('Staff removed: ' || p_login);
end $$;
revoke execute on function public.app_delete_staff(text) from anon;

-- ---------- principal ----------
create or replace function public.app_principal_home()
returns jsonb language plpgsql stable security definer set search_path = public as $$
begin
  perform public.require_staff('principal');
  return jsonb_build_object(
    'totals', jsonb_build_object(
      'classes', (select count(*) from public.classes),
      'students', (select count(*) from public.students),
      'staff', (select count(*) from public.staff_accounts),
      'liveSessions', (select count(*) from public.sessions where active),
      'sessionsToday', (select count(*) from public.sessions where started_at::date = current_date),
      'attendanceRate', coalesce((select round(100.0 * count(*) filter (where status <> 'ABSENT') / nullif(count(*),0))
        from public.attendance_records r join public.sessions s on s.id = r.session_id
        where s.started_at > now() - interval '30 days'), 0)),
    'liveSessions', coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'className', s.class_name,
        'subject', s.subject, 'teacherName', s.teacher_name, 'startedAt', s.started_at,
        'verified', (select count(*) from public.session_slots sl where sl.session_id = s.id and sl.verified),
        'seated', (select count(*) from public.session_slots sl where sl.session_id = s.id))
      order by s.started_at desc) from public.sessions s where s.active), '[]'::jsonb),
    'recentSessions', coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'className', s.class_name,
        'subject', s.subject, 'teacherName', s.teacher_name, 'startedAt', s.started_at, 'active', s.active,
        'present', (select count(*) from public.attendance_records r where r.session_id = s.id and r.status <> 'ABSENT'),
        'total', (select count(*) from public.attendance_records r where r.session_id = s.id))
      order by s.started_at desc) from (select * from public.sessions order by started_at desc limit 20) s), '[]'::jsonb),
    'activity', coalesce((select jsonb_agg(jsonb_build_object('message', a.message, 'at', a.created_at)
      order by a.created_at desc) from (select * from public.activity_log order by created_at desc limit 25) a), '[]'::jsonb)
  );
end $$;
revoke execute on function public.app_principal_home() from anon;

create or replace function public.app_session_report(p_session uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); s public.sessions;
begin
  if not (public.has_role(v_uid,'teacher') or public.has_role(v_uid,'admin') or public.has_role(v_uid,'principal')) then
    raise exception 'Not authorised';
  end if;
  select * into s from public.sessions where id = p_session;
  if not found then raise exception 'Unknown session'; end if;
  return jsonb_build_object('className', s.class_name, 'subject', s.subject,
    'teacherName', s.teacher_name, 'startedAt', s.started_at, 'endedAt', s.ended_at,
    'rows', coalesce((select jsonb_agg(jsonb_build_object('rollNumber', r.roll_number, 'name', r.name,
      'benchNumber', r.bench_number, 'status', r.status, 'verifiedByPartner', r.verified_by_partner,
      'recordedAt', r.recorded_at) order by r.bench_number, r.roll_number)
      from public.attendance_records r where r.session_id = p_session), '[]'::jsonb));
end $$;
revoke execute on function public.app_session_report(uuid) from anon;