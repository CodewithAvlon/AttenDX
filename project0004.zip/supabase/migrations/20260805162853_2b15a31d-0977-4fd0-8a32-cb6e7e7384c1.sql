alter table public.students alter column bench_number drop not null;
alter table public.students alter column seat drop not null;

create or replace function public.refresh_bench_occupancy(p_session uuid, p_bench integer)
returns public.bench_status
language plpgsql
security definer
set search_path = public
as $$
declare v_total int; v_ok int; v_status public.bench_status;
begin
  select count(*), count(*) filter (where verified) into v_total, v_ok
    from public.session_slots where session_id = p_session and bench_number = p_bench;
  if v_total = 0 then v_status := 'EMPTY';
  elsif v_ok >= v_total and v_total >= 2 then v_status := 'PRESENT';
  elsif v_ok > 0 then v_status := 'PARTIAL';
  elsif v_total = 1 then v_status := 'SINGLE';
  else v_status := 'PENDING';
  end if;
  update public.session_benches set status = v_status
    where session_id = p_session and bench_number = p_bench;
  return v_status;
end $$;

create or replace function public.recompute_bench(p_session uuid, p_bench integer)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare v_status public.bench_status; slot record;
begin
  v_status := public.refresh_bench_occupancy(p_session, p_bench);
  if v_status = 'PRESENT' then
    for slot in select * from public.session_slots where session_id = p_session and bench_number = p_bench loop
      perform public.finalize_attendance(p_session, slot.roll_number, slot.name, p_bench, 'PRESENT', true);
    end loop;
  end if;
end $$;

create or replace function public.app_start_session(p_class_id text, p_subject text, p_total_benches integer, p_timer_minutes integer)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_teacher public.staff_accounts := public.require_staff('teacher');
  v_class public.classes;
  v_session uuid;
  n int;
begin
  select * into v_class from public.classes where id = p_class_id;
  if not found then raise exception 'Unknown class'; end if;
  if coalesce(trim(p_subject), '') = '' then raise exception 'Subject is required'; end if;
  if p_total_benches < 1 or p_total_benches > 60 then raise exception 'Bench count must be between 1 and 60'; end if;
  if p_timer_minutes < 1 or p_timer_minutes > 60 then raise exception 'Timer must be between 1 and 60 minutes'; end if;
  if exists (select 1 from public.sessions where class_id = p_class_id and active) then
    raise exception 'A session is already running for this class. End or cancel it first.';
  end if;

  insert into public.sessions (class_id, class_name, subject, teacher_login, teacher_name, total_benches, duration_seconds)
  values (p_class_id, v_class.name, trim(p_subject), v_teacher.login_id, v_teacher.display_name,
          p_total_benches, p_timer_minutes * 60)
  returning id into v_session;

  for n in 1..p_total_benches loop
    insert into public.session_benches (session_id, bench_number, status) values (v_session, n, 'EMPTY');
  end loop;

  perform public.log_activity('Session started: ' || v_class.name || ' · ' || trim(p_subject));
  return v_session;
end $$;

create or replace function public.app_check_in(p_bench integer)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  st public.students; s public.sessions; me public.session_slots; b public.session_benches;
  v_count int; v_seat char(1); v_method public.verification_method;
begin
  select * into st from public.students where user_id = auth.uid();
  if not found then raise exception 'Not registered as a student'; end if;
  select * into s from public.sessions where class_id = st.class_id and active order by started_at desc limit 1;
  if not found then raise exception 'No attendance session is running for your class'; end if;

  select * into b from public.session_benches where session_id = s.id and bench_number = p_bench for update;
  if not found then raise exception 'Bench % is not part of this session', p_bench; end if;

  select * into me from public.session_slots where session_id = s.id and roll_number = st.roll_number;
  if me.roll_number is not null then
    if me.bench_number = p_bench then return public.app_student_session(); end if;
    if me.verified then
      raise exception 'You are already verified at bench %', me.bench_number;
    end if;
    delete from public.session_slots where session_id = s.id and roll_number = st.roll_number;
    perform public.refresh_bench_occupancy(s.id, me.bench_number);
  end if;

  select count(*) into v_count from public.session_slots where session_id = s.id and bench_number = p_bench;
  if v_count >= 2 then raise exception 'Bench % is already full. Pick another bench.', p_bench; end if;

  if v_count = 0 then
    v_seat := 'A';
    v_method := (case when random() < 0.5 then 'QR' else 'PASSCODE' end)::public.verification_method;
  else
    v_seat := 'B';
    select method into v_method from public.session_slots
      where session_id = s.id and bench_number = p_bench limit 1;
  end if;

  insert into public.session_slots (session_id, roll_number, bench_number, seat, name, method, code, entered)
  values (s.id, st.roll_number, p_bench, v_seat, st.name, v_method, public.gen_code(), true);

  perform public.refresh_bench_occupancy(s.id, p_bench);
  perform public.log_activity(st.name || ' took seat ' || v_seat || ' at bench ' || p_bench);
  return public.app_student_session();
end $$;

create or replace function public.app_verify_partner(p_code text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  st public.students; s public.sessions; me public.session_slots; partner public.session_slots;
  v_input text := upper(regexp_replace(coalesce(p_code,''), '\s', '', 'g'));
begin
  select * into st from public.students where user_id = auth.uid();
  if not found then raise exception 'Not registered as a student'; end if;
  select * into s from public.sessions where class_id = st.class_id and active order by started_at desc limit 1;
  if not found then raise exception 'No attendance session is running for your class'; end if;

  select * into me from public.session_slots where session_id = s.id and roll_number = st.roll_number for update;
  if not found then raise exception 'Pick a bench first'; end if;
  if me.verified then return public.app_student_session(); end if;
  if me.failed_attempts >= 5 then
    raise exception 'Too many incorrect attempts. Ask your teacher to verify you manually.';
  end if;

  select * into partner from public.session_slots
    where session_id = s.id and bench_number = me.bench_number and roll_number <> me.roll_number limit 1;
  if partner.roll_number is null then
    raise exception 'Nobody has joined your bench yet. Wait for a partner or ask your teacher.';
  end if;

  if v_input <> partner.code then
    update public.session_slots set failed_attempts = failed_attempts + 1
      where session_id = s.id and roll_number = me.roll_number;
    perform public.log_activity('Failed verification by ' || st.name || ' (bench ' || me.bench_number || ')');
    return public.app_student_session() || jsonb_build_object('lastResult', 'INCORRECT');
  end if;

  update public.session_slots set verified = true, failed_attempts = 0
    where session_id = s.id and roll_number = me.roll_number;
  perform public.recompute_bench(s.id, me.bench_number);
  perform public.log_activity(st.name || ' verified at bench ' || me.bench_number);
  return public.app_student_session() || jsonb_build_object('lastResult', 'VERIFIED');
end $$;

create or replace function public.app_student_session()
returns jsonb
language plpgsql
stable security definer
set search_path = public
as $$
declare st public.students; s public.sessions; me public.session_slots; v jsonb;
begin
  select * into st from public.students where user_id = auth.uid();
  if not found then raise exception 'Not registered as a student'; end if;
  select * into s from public.sessions where class_id = st.class_id and active
    order by started_at desc limit 1;
  if not found then return jsonb_build_object('active', false); end if;
  select * into me from public.session_slots where session_id = s.id and roll_number = st.roll_number;

  v := jsonb_build_object(
    'active', true,
    'sessionId', s.id,
    'subject', s.subject,
    'className', s.class_name,
    'teacherName', s.teacher_name,
    'totalBenches', s.total_benches,
    'myBench', me.bench_number,
    'mySeat', me.seat,
    'remainingSeconds', greatest(0, s.duration_seconds - floor(extract(epoch from (now() - s.started_at)))::int),
    'seated', me.roll_number is not null,
    'layout', (select jsonb_build_object('rows', bl.grid_rows, 'cols', bl.grid_cols, 'cells', bl.cells)
               from public.bench_layouts bl where bl.class_id = s.class_id),
    'benches', coalesce((select jsonb_agg(jsonb_build_object(
        'benchNumber', b.bench_number, 'status', b.status,
        'seats', coalesce((select jsonb_agg(jsonb_build_object(
            'seat', sl.seat, 'name', sl.name, 'verified', sl.verified,
            'mine', sl.roll_number = st.roll_number) order by sl.seat)
          from public.session_slots sl
          where sl.session_id = s.id and sl.bench_number = b.bench_number), '[]'::jsonb)
      ) order by b.bench_number)
      from public.session_benches b where b.session_id = s.id), '[]'::jsonb)
  );

  if me.roll_number is not null then
    v := v || jsonb_build_object(
      'benchStatus', (select status from public.session_benches
        where session_id = s.id and bench_number = me.bench_number),
      'method', me.method, 'myCode', me.code, 'entered', me.entered,
      'verified', me.verified, 'failedAttempts', me.failed_attempts,
      'attemptsLeft', greatest(0, 5 - me.failed_attempts),
      'locked', me.failed_attempts >= 5 and not me.verified,
      'partnerName', (select sl.name from public.session_slots sl
        where sl.session_id = s.id and sl.bench_number = me.bench_number and sl.roll_number <> me.roll_number limit 1),
      'partnerVerified', coalesce((select sl.verified from public.session_slots sl
        where sl.session_id = s.id and sl.bench_number = me.bench_number and sl.roll_number <> me.roll_number limit 1), false),
      'status', (select status::text from public.attendance_records
        where session_id = s.id and roll_number = st.roll_number)
    );
  end if;
  return v;
end $$;

create or replace function public.close_session(p_session uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare s public.sessions; slot record; stu record;
begin
  select * into s from public.sessions where id = p_session and active for update;
  if not found then return; end if;
  for slot in select * from public.session_slots where session_id = p_session loop
    if not exists (select 1 from public.attendance_records where session_id = p_session and roll_number = slot.roll_number) then
      perform public.finalize_attendance(p_session, slot.roll_number, slot.name, slot.bench_number, 'ABSENT', false);
    end if;
  end loop;
  for stu in select * from public.students where class_id = s.class_id loop
    if not exists (select 1 from public.attendance_records where session_id = p_session and roll_number = stu.roll_number) then
      perform public.finalize_attendance(p_session, stu.roll_number, stu.name, 0, 'ABSENT', false);
    end if;
  end loop;
  update public.sessions set active = false, ended_at = now() where id = p_session;
  perform public.log_activity('Session ended: ' || s.class_name || ' · ' || s.subject);
end $$;

create or replace function public.app_set_bench_status(p_session uuid, p_bench integer, p_status text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare v_target public.bench_status; slot record;
begin
  perform public.require_staff('teacher');
  if not exists (select 1 from public.sessions where id = p_session and active) then
    raise exception 'No matching active session';
  end if;
  if not exists (select 1 from public.session_benches where session_id = p_session and bench_number = p_bench) then
    raise exception 'Unknown bench: %', p_bench;
  end if;
  if upper(coalesce(p_status,'')) not in ('EMPTY','SINGLE','PRESENT') then
    raise exception 'Status must be EMPTY, SINGLE, or PRESENT';
  end if;
  v_target := upper(p_status)::public.bench_status;

  if v_target = 'EMPTY' then
    for slot in select * from public.session_slots where session_id = p_session and bench_number = p_bench loop
      perform public.finalize_attendance(p_session, slot.roll_number, slot.name, p_bench, 'ABSENT', false);
    end loop;
    update public.session_benches set status = 'EMPTY' where session_id = p_session and bench_number = p_bench;
    perform public.log_activity('Bench ' || p_bench || ' marked empty by teacher');
  elsif v_target = 'SINGLE' then
    update public.session_benches set status = 'SINGLE' where session_id = p_session and bench_number = p_bench;
    perform public.log_activity('Bench ' || p_bench || ' marked single-occupant by teacher');
  else
    for slot in select * from public.session_slots where session_id = p_session and bench_number = p_bench loop
      update public.session_slots set verified = true
        where session_id = p_session and roll_number = slot.roll_number;
      perform public.finalize_attendance(p_session, slot.roll_number, slot.name, p_bench, 'PRESENT', false);
    end loop;
    update public.session_benches set status = 'PRESENT' where session_id = p_session and bench_number = p_bench;
    perform public.log_activity('Bench ' || p_bench || ' force-marked present by teacher');
  end if;
end $$;

drop function if exists public.app_upsert_student(text, text, text, integer, text, text);

create or replace function public.app_upsert_student(p_roll text, p_name text, p_class_id text)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare v_roll text := upper(trim(coalesce(p_roll,'')));
begin
  perform public.require_staff('admin');
  if v_roll = '' or coalesce(trim(p_name),'') = '' then raise exception 'Roll number and name are required'; end if;
  if not exists (select 1 from public.classes where id = p_class_id) then raise exception 'Unknown class'; end if;
  insert into public.students (roll_number, name, class_id)
  values (v_roll, trim(p_name), p_class_id)
  on conflict (roll_number) do update set name = excluded.name, class_id = excluded.class_id;
  perform public.log_activity('Student saved: ' || v_roll);
end $$;

create or replace function public.app_admin_home()
returns jsonb
language plpgsql
stable security definer
set search_path = public
as $$
begin
  perform public.require_staff('admin');
  return jsonb_build_object(
    'classes', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'name', c.name,
        'studentCount', (select count(*) from public.students st where st.class_id = c.id),
        'layout', (select jsonb_build_object('rows', bl.grid_rows, 'cols', bl.grid_cols, 'cells', bl.cells)
                   from public.bench_layouts bl where bl.class_id = c.id))
      order by c.name) from public.classes c), '[]'::jsonb),
    'students', coalesce((select jsonb_agg(jsonb_build_object('rollNumber', st.roll_number, 'name', st.name,
        'classId', st.class_id, 'registered', st.user_id is not null,
        'sessionsCounted', (select count(*) from public.attendance_records r where r.roll_number = st.roll_number),
        'presentCount', (select count(*) from public.attendance_records r
           where r.roll_number = st.roll_number and r.status <> 'ABSENT'))
      order by st.class_id, st.roll_number) from public.students st), '[]'::jsonb),
    'staff', coalesce((select jsonb_agg(jsonb_build_object('loginId', sa.login_id, 'name', sa.display_name,
        'role', sa.role, 'registered', sa.user_id is not null) order by sa.role, sa.login_id)
      from public.staff_accounts sa), '[]'::jsonb),
    'sessions', coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'className', s.class_name,
        'subject', s.subject, 'teacherName', s.teacher_name, 'active', s.active, 'startedAt', s.started_at)
      order by s.started_at desc) from (select * from public.sessions order by started_at desc limit 30) s), '[]'::jsonb)
  );
end $$;

create or replace function public.app_me()
returns jsonb
language plpgsql
stable security definer
set search_path = public
as $$
declare v_uid uuid := auth.uid(); v jsonb; s public.students;
begin
  if v_uid is null then return null; end if;
  select jsonb_build_object('loginId', p.login_id, 'name', p.display_name,
           'role', (select role from public.user_roles where user_id = v_uid limit 1))
    into v from public.profiles p where p.id = v_uid;
  if v is null then return null; end if;
  select * into s from public.students where user_id = v_uid;
  if found then
    v := v || jsonb_build_object('rollNumber', s.roll_number, 'classId', s.class_id,
         'className', (select name from public.classes where id = s.class_id));
  end if;
  return v;
end $$;