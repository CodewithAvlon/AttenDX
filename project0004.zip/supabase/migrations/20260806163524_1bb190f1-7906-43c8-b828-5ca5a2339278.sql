create or replace function public.app_class_previous_session(p_class_id text)
returns jsonb
language plpgsql
stable security definer
set search_path = public
as $$
declare v_uid uuid := auth.uid(); s public.sessions;
begin
  if not (public.has_role(v_uid,'teacher') or public.has_role(v_uid,'admin') or public.has_role(v_uid,'principal')) then
    raise exception 'Not authorised';
  end if;
  select * into s from public.sessions
    where class_id = p_class_id and not active
    order by coalesce(ended_at, started_at) desc limit 1;
  if not found then return null; end if;
  return jsonb_build_object(
    'sessionId', s.id, 'className', s.class_name, 'subject', s.subject,
    'teacherName', s.teacher_name, 'startedAt', s.started_at, 'endedAt', s.ended_at,
    'singleBenches', coalesce((select jsonb_agg(jsonb_build_object('benchNumber', b.bench_number,
        'students', coalesce((select jsonb_agg(r.name order by r.name) from public.attendance_records r
           where r.session_id = s.id and r.bench_number = b.bench_number), '[]'::jsonb))
        order by b.bench_number)
      from public.session_benches b where b.session_id = s.id and b.status = 'SINGLE'), '[]'::jsonb),
    'emptyBenches', coalesce((select jsonb_agg(b.bench_number order by b.bench_number)
      from public.session_benches b where b.session_id = s.id and b.status = 'EMPTY'), '[]'::jsonb),
    'absentees', coalesce((select jsonb_agg(jsonb_build_object('rollNumber', r.roll_number,
        'name', r.name, 'benchNumber', r.bench_number) order by r.roll_number)
      from public.attendance_records r where r.session_id = s.id and r.status = 'ABSENT'), '[]'::jsonb)
  );
end $$;