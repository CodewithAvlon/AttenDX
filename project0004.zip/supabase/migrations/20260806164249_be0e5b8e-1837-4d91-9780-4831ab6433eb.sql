create or replace function public.app_class_today_sessions(p_class_id text)
returns jsonb
language plpgsql
stable
security definer
set search_path = public
as $$
declare v_uid uuid := auth.uid();
begin
  if not (public.has_role(v_uid,'teacher') or public.has_role(v_uid,'admin') or public.has_role(v_uid,'principal')) then
    raise exception 'Not authorised';
  end if;

  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'sessionId', s.id,
      'className', s.class_name,
      'subject', s.subject,
      'teacherName', s.teacher_name,
      'startedAt', s.started_at,
      'endedAt', s.ended_at,
      'benches', coalesce((
        select jsonb_agg(jsonb_build_object(
          'benchNumber', b.bench_number,
          'status', b.status,
          'students', coalesce((
            select jsonb_agg(jsonb_build_object('name', r.name, 'rollNumber', r.roll_number, 'status', r.status)
                   order by r.roll_number)
            from public.attendance_records r
            where r.session_id = s.id and r.bench_number = b.bench_number
          ), '[]'::jsonb)
        ) order by b.bench_number)
        from public.session_benches b where b.session_id = s.id
      ), '[]'::jsonb),
      'singleBenches', coalesce((
        select jsonb_agg(jsonb_build_object('benchNumber', b.bench_number,
          'students', coalesce((select jsonb_agg(r.name order by r.name) from public.attendance_records r
             where r.session_id = s.id and r.bench_number = b.bench_number), '[]'::jsonb))
          order by b.bench_number)
        from public.session_benches b where b.session_id = s.id and b.status = 'SINGLE'
      ), '[]'::jsonb),
      'emptyBenches', coalesce((
        select jsonb_agg(b.bench_number order by b.bench_number)
        from public.session_benches b where b.session_id = s.id and b.status = 'EMPTY'
      ), '[]'::jsonb),
      'absentees', coalesce((
        select jsonb_agg(jsonb_build_object('rollNumber', r.roll_number, 'name', r.name,
               'benchNumber', r.bench_number) order by r.roll_number)
        from public.attendance_records r where r.session_id = s.id and r.status = 'ABSENT'
      ), '[]'::jsonb)
    ) order by coalesce(s.ended_at, s.started_at) desc)
    from public.sessions s
    where s.class_id = p_class_id
      and not s.active
      and (coalesce(s.ended_at, s.started_at) at time zone 'utc')::date = (now() at time zone 'utc')::date
  ), '[]'::jsonb);
end $$;