create or replace function public.app_start_session(
  p_class_id text,
  p_subject text,
  p_total_benches integer default null,
  p_timer_minutes integer default 5
)
 returns uuid
 language plpgsql
 security definer
 set search_path to 'public'
as $function$
declare
  v_teacher public.staff_accounts := public.require_staff('teacher');
  v_class public.classes;
  v_session uuid;
  v_benches int;
  n int;
begin
  select * into v_class from public.classes where id = p_class_id;
  if not found then raise exception 'Unknown class'; end if;
  if coalesce(trim(p_subject), '') = '' then raise exception 'Subject is required'; end if;
  if p_timer_minutes < 1 or p_timer_minutes > 60 then raise exception 'Timer must be between 1 and 60 minutes'; end if;

  v_benches := p_total_benches;
  if v_benches is null then
    select jsonb_array_length(bl.cells) into v_benches
      from public.bench_layouts bl where bl.class_id = p_class_id;
  end if;
  if coalesce(v_benches, 0) < 1 then
    select greatest(1, ceil(count(*)::numeric / 2))::int into v_benches
      from public.students st where st.class_id = p_class_id;
  end if;
  v_benches := least(greatest(coalesce(v_benches, 1), 1), 60);

  if exists (select 1 from public.sessions where class_id = p_class_id and active) then
    raise exception 'A session is already running for this class. End or cancel it first.';
  end if;

  insert into public.sessions (class_id, class_name, subject, teacher_login, teacher_name, total_benches, duration_seconds)
  values (p_class_id, v_class.name, trim(p_subject), v_teacher.login_id, v_teacher.display_name,
          v_benches, p_timer_minutes * 60)
  returning id into v_session;

  for n in 1..v_benches loop
    insert into public.session_benches (session_id, bench_number, status) values (v_session, n, 'EMPTY');
  end loop;

  perform public.log_activity('Session started: ' || v_class.name || ' · ' || trim(p_subject));
  return v_session;
end $function$;