create or replace function public.app_admin_home()
 returns jsonb
 language plpgsql
 stable security definer
 set search_path to 'public'
as $function$
begin
  perform public.require_staff('admin');
  return jsonb_build_object(
    'classes', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'name', c.name,
        'studentCount', (select count(*) from public.students st where st.class_id = c.id),
        'layout', (select jsonb_build_object('rows', bl.grid_rows, 'cols', bl.grid_cols, 'cells', bl.cells)
                   from public.bench_layouts bl where bl.class_id = c.id))
      order by c.name) from public.classes c), '[]'::jsonb),
    'students', coalesce((select jsonb_agg(jsonb_build_object('rollNumber', st.roll_number, 'name', st.name,
        'classId', st.class_id, 'registered', st.user_id is not null,
        'sessionsCounted', (select count(*) from public.attendance_records r where r.roll_number = st.roll_number),
        'presentCount', (select count(*) from public.attendance_records r
           where r.roll_number = st.roll_number and r.status <> 'ABSENT'))
      order by st.class_id, st.roll_number) from public.students st), '[]'::jsonb),
    'staff', coalesce((select jsonb_agg(jsonb_build_object('loginId', sa.login_id, 'name', sa.display_name,
        'role', sa.role, 'registered', sa.user_id is not null) order by sa.role, sa.login_id)
      from public.staff_accounts sa), '[]'::jsonb),
    'sessions', coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'className', s.class_name,
        'subject', s.subject, 'teacherName', s.teacher_name, 'active', s.active, 'startedAt', s.started_at)
      order by s.started_at desc) from (select * from public.sessions order by started_at desc limit 30) s), '[]'::jsonb),
    'activity', coalesce((select jsonb_agg(jsonb_build_object('message', a.message, 'at', a.created_at)
      order by a.created_at desc) from (select * from public.activity_log order by created_at desc limit 40) a), '[]'::jsonb)
  );
end $function$;