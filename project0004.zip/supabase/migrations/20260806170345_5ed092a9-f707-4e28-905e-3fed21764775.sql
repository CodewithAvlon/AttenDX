CREATE TABLE public.timetable (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  teacher_login text NOT NULL,
  class_id text NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  subject text NOT NULL,
  day_of_week smallint NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
  start_time time NOT NULL,
  end_time time NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (teacher_login, day_of_week, start_time, class_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.timetable TO authenticated;
GRANT ALL ON public.timetable TO service_role;

ALTER TABLE public.timetable ENABLE ROW LEVEL SECURITY;

CREATE POLICY "staff read timetable" ON public.timetable FOR SELECT TO authenticated
USING (public.has_role(auth.uid(),'teacher') OR public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'principal'));

CREATE INDEX timetable_teacher_day_idx ON public.timetable (teacher_login, day_of_week, start_time);

CREATE OR REPLACE FUNCTION public.tt_touch() RETURNS trigger
LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

CREATE TRIGGER timetable_touch BEFORE UPDATE ON public.timetable
FOR EACH ROW EXECUTE FUNCTION public.tt_touch();

-- local "now" used for schedule matching
CREATE OR REPLACE FUNCTION public.app_local_now() RETURNS timestamp
LANGUAGE sql STABLE SET search_path = public AS $$
  SELECT (now() AT TIME ZONE 'Asia/Kolkata')
$$;

-- admin: list full timetable
CREATE OR REPLACE FUNCTION public.app_timetable_all()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.require_staff('admin');
  RETURN coalesce((SELECT jsonb_agg(jsonb_build_object(
    'id', t.id, 'teacherLogin', t.teacher_login,
    'teacherName', (SELECT display_name FROM public.staff_accounts sa WHERE lower(sa.login_id)=lower(t.teacher_login)),
    'classId', t.class_id,
    'className', (SELECT name FROM public.classes c WHERE c.id = t.class_id),
    'subject', t.subject, 'dayOfWeek', t.day_of_week,
    'startTime', to_char(t.start_time,'HH24:MI'), 'endTime', to_char(t.end_time,'HH24:MI'))
    ORDER BY t.day_of_week, t.start_time, t.teacher_login) FROM public.timetable t), '[]'::jsonb);
END $$;

-- admin: bulk upsert entries [{teacherLogin, classId, subject, dayOfWeek, startTime, endTime}]
CREATE OR REPLACE FUNCTION public.app_save_timetable(p_entries jsonb, p_replace boolean DEFAULT false)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE e jsonb; v_login text; v_count int := 0;
BEGIN
  PERFORM public.require_staff('admin');
  IF p_entries IS NULL OR jsonb_typeof(p_entries) <> 'array' THEN
    RAISE EXCEPTION 'A list of timetable rows is required';
  END IF;
  IF p_replace THEN DELETE FROM public.timetable; END IF;

  FOR e IN SELECT * FROM jsonb_array_elements(p_entries) LOOP
    SELECT login_id INTO v_login FROM public.staff_accounts
      WHERE lower(login_id) = lower(trim(e->>'teacherLogin')) AND role = 'teacher';
    IF v_login IS NULL THEN
      RAISE EXCEPTION 'Unknown teacher ID: %', coalesce(e->>'teacherLogin','(blank)');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM public.classes WHERE id = e->>'classId') THEN
      RAISE EXCEPTION 'Unknown class: %', coalesce(e->>'classId','(blank)');
    END IF;
    IF coalesce(trim(e->>'subject'),'') = '' THEN RAISE EXCEPTION 'Subject is required'; END IF;

    INSERT INTO public.timetable (teacher_login, class_id, subject, day_of_week, start_time, end_time)
    VALUES (v_login, e->>'classId', trim(e->>'subject'), (e->>'dayOfWeek')::smallint,
            (e->>'startTime')::time, (e->>'endTime')::time)
    ON CONFLICT (teacher_login, day_of_week, start_time, class_id)
      DO UPDATE SET subject = excluded.subject, end_time = excluded.end_time, updated_at = now();
    v_count := v_count + 1;
  END LOOP;

  PERFORM public.log_activity('Timetable updated (' || v_count || ' rows)');
  RETURN jsonb_build_object('saved', v_count);
END $$;

CREATE OR REPLACE FUNCTION public.app_delete_timetable_entry(p_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  PERFORM public.require_staff('admin');
  DELETE FROM public.timetable WHERE id = p_id;
  PERFORM public.log_activity('Timetable row removed');
END $$;

-- teacher: today's schedule + current/next suggestion
CREATE OR REPLACE FUNCTION public.app_my_schedule()
RETURNS jsonb LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE v public.staff_accounts := public.require_staff('teacher');
        v_now timestamp := public.app_local_now();
        v_dow smallint := extract(dow FROM v_now)::smallint;
        v_time time := v_now::time;
        v_today jsonb; v_current jsonb; v_next jsonb;
BEGIN
  SELECT coalesce(jsonb_agg(jsonb_build_object(
      'id', t.id, 'classId', t.class_id,
      'className', (SELECT name FROM public.classes c WHERE c.id = t.class_id),
      'subject', t.subject,
      'startTime', to_char(t.start_time,'HH24:MI'), 'endTime', to_char(t.end_time,'HH24:MI'),
      'current', v_time >= t.start_time AND v_time < t.end_time)
      ORDER BY t.start_time), '[]'::jsonb)
    INTO v_today
    FROM public.timetable t
    WHERE lower(t.teacher_login) = lower(v.login_id) AND t.day_of_week = v_dow;

  SELECT jsonb_build_object('id', t.id, 'classId', t.class_id,
      'className', (SELECT name FROM public.classes c WHERE c.id = t.class_id),
      'subject', t.subject,
      'startTime', to_char(t.start_time,'HH24:MI'), 'endTime', to_char(t.end_time,'HH24:MI'))
    INTO v_current
    FROM public.timetable t
    WHERE lower(t.teacher_login) = lower(v.login_id) AND t.day_of_week = v_dow
      AND v_time >= t.start_time AND v_time < t.end_time
    ORDER BY t.start_time LIMIT 1;

  SELECT jsonb_build_object('id', t.id, 'classId', t.class_id,
      'className', (SELECT name FROM public.classes c WHERE c.id = t.class_id),
      'subject', t.subject,
      'startTime', to_char(t.start_time,'HH24:MI'), 'endTime', to_char(t.end_time,'HH24:MI'))
    INTO v_next
    FROM public.timetable t
    WHERE lower(t.teacher_login) = lower(v.login_id) AND t.day_of_week = v_dow
      AND t.start_time > v_time
    ORDER BY t.start_time LIMIT 1;

  RETURN jsonb_build_object('dayOfWeek', v_dow, 'localTime', to_char(v_time,'HH24:MI'),
    'today', v_today, 'current', v_current, 'next', v_next);
END $$;