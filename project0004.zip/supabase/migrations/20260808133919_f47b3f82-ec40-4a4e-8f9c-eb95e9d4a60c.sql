insert into public.students (roll_number, name, class_id) values
 ('2024CS011','Ananya Rao','cse-s3-a'),
 ('2024CS012','Vikram Nair','cse-s3-a'),
 ('2024CS013','Sara Khan','cse-s3-a')
on conflict (roll_number) do nothing;

insert into public.staff_accounts (login_id, display_name, role) values
 ('TCH004','Prof. Menon','teacher'),
 ('ADMIN3','Office Admin','admin'),
 ('PRIN003','Principal Desk','principal')
on conflict (login_id) do nothing;