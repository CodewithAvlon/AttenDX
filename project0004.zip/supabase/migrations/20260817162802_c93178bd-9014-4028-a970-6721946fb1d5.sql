CREATE TABLE public.late_entries (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  class_id text NOT NULL REFERENCES public.classes(id) ON DELETE CASCADE,
  roll_number text NOT NULL,
  name text NOT NULL,
  marked_by text NOT NULL,
  marked_at timestamptz NOT NULL DEFAULT now(),
  session_id uuid REFERENCES public.sessions(id) ON DELETE SET NULL,
  applied boolean NOT NULL DEFAULT false
);

CREATE UNIQUE INDEX late_entries_pending_uniq
  ON public.late_entries (class_id, roll_number) WHERE NOT applied;
CREATE INDEX late_entries_roll_idx ON public.late_entries (roll_number, marked_at DESC);

GRANT SELECT ON public.late_entries TO authenticated;
GRANT ALL ON public.late_entries TO service_role;
ALTER TABLE public.late_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "staff read late entries" ON public.late_entries FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(),'teacher') OR public.has_role(auth.uid(),'admin') OR public.has_role(auth.uid(),'principal'));
CREATE POLICY "own late entries" ON public.late_entries FOR SELECT TO authenticated
  USING (roll_number = public.my_roll());

-- Convert PRESENT into LATE when a pending late mark exists for the student
CREATE OR REPLACE FUNCTION public.apply_late_entry()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_class text; v_flag public.late_entries;
BEGIN
  IF NEW.status <> 'PRESENT' THEN RETURN NEW; END IF;
  SELECT class_id INTO v_class FROM public.sessions WHERE id = NEW.session_id;
  IF v_class IS NULL THEN RETURN NEW; END IF;
  SELECT * INTO v_flag FROM public.late_entries
    WHERE class_id = v_class AND roll_number = NEW.roll_number AND NOT applied
    ORDER BY marked_at LIMIT 1;
  IF v_flag.id IS NULL THEN RETURN NEW; END IF;
  UPDATE public.late_entries SET applied = true, session_id = NEW.session_id WHERE id = v_flag.id;
  NEW.status := 'LATE';
  RETURN NEW;
END $$;

DROP TRIGGER IF EXISTS attendance_apply_late ON public.attendance_records;
CREATE TRIGGER attendance_apply_late
  BEFORE INSERT OR UPDATE ON public.attendance_records
  FOR EACH ROW EXECUTE FUNCTION public.apply_late_entry();

-- Mark a late entry any time (session live or not)
CREATE OR REPLACE FUNCTION public.app_mark_late_entry(p_class_id text, p_roll text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v public.staff_accounts := public.require_staff('teacher');
        st public.students; s public.sessions;
BEGIN
  SELECT * INTO st FROM public.students WHERE lower(roll_number) = lower(trim(p_roll));
  IF NOT FOUND THEN RAISE EXCEPTION 'Student not found: %', p_roll; END IF;
  IF st.class_id <> p_class_id THEN RAISE EXCEPTION '% is not in this class', st.roll_number; END IF;

  INSERT INTO public.late_entries (class_id, roll_number, name, marked_by)
  VALUES (st.class_id, st.roll_number, st.name, v.display_name)
  ON CONFLICT (class_id, roll_number) WHERE NOT applied DO NOTHING;

  SELECT * INTO s FROM public.sessions WHERE class_id = st.class_id AND active
    ORDER BY started_at DESC LIMIT 1;
  IF FOUND AND EXISTS (SELECT 1 FROM public.attendance_records
      WHERE session_id = s.id AND roll_number = st.roll_number) THEN
    UPDATE public.late_entries SET applied = true, session_id = s.id
      WHERE class_id = st.class_id AND roll_number = st.roll_number AND NOT applied;
    PERFORM public.finalize_attendance(s.id, st.roll_number, st.name,
      coalesce(st.bench_number, 0), 'LATE', false);
  END IF;

  PERFORM public.log_activity('Late entry marked: ' || st.name || ' (' || st.roll_number || ') by ' || v.display_name);
END $$;

CREATE OR REPLACE FUNCTION public.app_clear_late_entry(p_class_id text, p_roll text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  PERFORM public.require_staff('teacher');
  DELETE FROM public.late_entries
    WHERE class_id = p_class_id AND lower(roll_number) = lower(trim(p_roll)) AND NOT applied;
  PERFORM public.log_activity('Late entry mark removed: ' || p_roll);
END $$;

CREATE OR REPLACE FUNCTION public.app_late_board(p_class_id text)
RETURNS jsonb
LANGUAGE plpgsql
STABLE SECURITY DEFINER
SET search_path = public
AS $$
DECLARE v_uid uuid := auth.uid();
BEGIN
  IF NOT (public.has_role(v_uid,'teacher') OR public.has_role(v_uid,'admin') OR public.has_role(v_uid,'principal')) THEN
    RAISE EXCEPTION 'Not authorised';
  END IF;
  RETURN jsonb_build_object(
    'students', coalesce((SELECT jsonb_agg(jsonb_build_object(
        'rollNumber', st.roll_number, 'name', st.name,
        'pending', EXISTS (SELECT 1 FROM public.late_entries le
          WHERE le.class_id = st.class_id AND le.roll_number = st.roll_number AND NOT le.applied))
        ORDER BY st.roll_number)
      FROM public.students st WHERE st.class_id = p_class_id), '[]'::jsonb),
    'pending', coalesce((SELECT jsonb_agg(jsonb_build_object(
        'rollNumber', le.roll_number, 'name', le.name, 'markedBy', le.marked_by, 'markedAt', le.marked_at)
        ORDER BY le.marked_at DESC)
      FROM public.late_entries le WHERE le.class_id = p_class_id AND NOT le.applied), '[]'::jsonb),
    'recent', coalesce((SELECT jsonb_agg(jsonb_build_object(
        'rollNumber', le.roll_number, 'name', le.name, 'markedBy', le.marked_by, 'markedAt', le.marked_at)
        ORDER BY le.marked_at DESC)
      FROM (SELECT * FROM public.late_entries WHERE class_id = p_class_id AND applied
            ORDER BY marked_at DESC LIMIT 15) le), '[]'::jsonb)
  );
END $$;