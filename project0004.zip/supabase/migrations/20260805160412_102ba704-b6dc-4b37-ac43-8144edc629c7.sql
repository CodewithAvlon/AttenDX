revoke execute on function public.has_role(uuid, public.app_role) from anon;

-- ---------- helpers ----------
create or replace function public.gen_code()
returns text language plpgsql volatile set search_path = public as $$
declare alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; out text := ''; i int;
begin
  for i in 1..4 loop
    out := out || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
  end loop;
  return out;
end $$;

create or replace function public.log_activity(p_message text)
returns void language sql volatile security definer set search_path = public as $$
  insert into public.activity_log (message) values (p_message);
$$;
revoke execute on function public.log_activity(text) from anon, authenticated;

create or replace function public.my_roll()
returns text language sql stable security definer set search_path = public as $$
  select roll_number from public.students where user_id = auth.uid()
$$;
revoke execute on function public.my_roll() from anon;

create or replace function public.require_staff(p_role public.app_role)
returns public.staff_accounts language plpgsql stable security definer set search_path = public as $$
declare v public.staff_accounts;
begin
  select * into v from public.staff_accounts where user_id = auth.uid() and role = p_role;
  if not found then raise exception 'Not authorised: % access required', p_role; end if;
  return v;
end $$;
revoke execute on function public.require_staff(public.app_role) from anon;

-- ---------- account claiming ----------
create or replace function public.claim_account(p_login_id text)
returns jsonb language plpgsql volatile security definer set search_path = public as $$
declare
  v_uid uuid := auth.uid();
  v_login text := trim(coalesce(p_login_id, ''));
  v_role public.app_role;
  v_name text;
  v_canonical text;
  v_owner uuid;
begin
  if v_uid is null then raise exception 'Not signed in'; end if;
  if v_login = '' then raise exception 'An ID is required'; end if;

  select roll_number, name, user_id into v_canonical, v_name, v_owner
    from public.students where lower(roll_number) = lower(v_login);

  if v_canonical is not null then
    if v_owner is not null and v_owner <> v_uid then
      raise exception 'That roll number has already been registered';
    end if;
    update public.students set user_id = v_uid where roll_number = v_canonical;
    v_role := 'student';
  else
    select login_id, display_name, role, user_id into v_canonical, v_name, v_role, v_owner
      from public.staff_accounts where lower(login_id) = lower(v_login);
    if v_canonical is null then
      raise exception 'That ID is not on the roster. Ask an administrator to add it.';
    end if;
    if v_owner is not null and v_owner <> v_uid then
      raise exception 'That ID has already been registered';
    end if;
    update public.staff_accounts set user_id = v_uid where login_id = v_canonical;
  end if;

  insert into public.profiles (id, login_id, display_name)
    values (v_uid, v_canonical, v_name)
    on conflict (id) do update set login_id = excluded.login_id, display_name = excluded.display_name;
  insert into public.user_roles (user_id, role) values (v_uid, v_role) on conflict do nothing;

  return jsonb_build_object('role', v_role, 'loginId', v_canonical, 'name', v_name);
end $$;
revoke execute on function public.claim_account(text) from anon;

create or replace function public.app_me()
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_uid uuid := auth.uid(); v jsonb; s public.students;
begin
  if v_uid is null then return null; end if;
  select jsonb_build_object('loginId', p.login_id, 'name', p.display_name,
           'role', (select role from public.user_roles where user_id = v_uid limit 1))
    into v from public.profiles p where p.id = v_uid;
  if v is null then return null; end if;
  select * into s from public.students where user_id = v_uid;
  if found then
    v := v || jsonb_build_object('rollNumber', s.roll_number, 'classId', s.class_id,
         'benchNumber', s.bench_number, 'seat', s.seat, 'partnerRoll', s.partner_roll,
         'className', (select name from public.classes where id = s.class_id));
  end if;
  return v;
end $$;
revoke execute on function public.app_me() from anon;

-- ---------- attendance finalisation ----------
create or replace function public.finalize_attendance(
  p_session uuid, p_roll text, p_name text, p_bench int,
  p_status public.attendance_status, p_verified boolean)
returns void language sql volatile security definer set search_path = public as $$
  insert into public.attendance_records (session_id, roll_number, name, bench_number, status, verified_by_partner, recorded_at)
  values (p_session, p_roll, p_name, p_bench, p_status, p_verified, now())
  on conflict (session_id, roll_number) do update
    set status = excluded.status, verified_by_partner = excluded.verified_by_partner,
        recorded_at = excluded.recorded_at, bench_number = excluded.bench_number;
$$;
revoke execute on function public.finalize_attendance(uuid, text, text, int, public.attendance_status, boolean) from anon, authenticated;

-- ---------- session lifecycle ----------
create or replace function public.app_start_session(
  p_class_id text, p_subject text, p_total_benches int, p_timer_minutes int)
returns uuid language plpgsql volatile security definer set search_path = public as $$
declare
  v_teacher public.staff_accounts := public.require_staff('teacher');
  v_class public.classes;
  v_session uuid;
  n int;
  a public.students;
  b public.students;
  v_status public.bench_status;
  v_method public.verification_method;
begin
  select * into v_class from public.classes where id = p_class_id;
  if not found then raise exception 'Unknown class'; end if;
  if coalesce(trim(p_subject), '') = '' then raise exception 'Subject is required'; end if;
  if p_total_benches < 1 or p_total_benches > 60 then raise exception 'Bench count must be between 1 and 60'; end if;
  if p_timer_minutes < 1 or p_timer_minutes > 60 then raise exception 'Timer must be between 1 and 60 minutes'; end if;
  if exists (select 1 from public.sessions where class_id = p_class_id and active) then
    raise exception 'A session is already running for this class. End or cancel it first.';
  end if;

  insert into public.sessions (class_id, class_name, subject, teacher_login, teacher_name, total_benches, duration_seconds)
  values (p_class_id, v_class.name, trim(p_subject), v_teacher.login_id, v_teacher.display_name,
          p_total_benches, p_timer_minutes * 60)
  returning id into v_session;

  for n in 1..p_total_benches loop
    select * into a from public.students where class_id = p_class_id and bench_number = n and seat = 'A' limit 1;
    if not found then a := null; end if;
    select * into b from public.students where class_id = p_class_id and bench_number = n and seat = 'B' limit 1;
    if not found then b := null; end if;

    if a.roll_number is null and b.roll_number is null then
      v_status := 'EMPTY';
    elsif a.roll_number is null or b.roll_number is null then
      v_status := 'SINGLE';
      insert into public.session_slots (session_id, roll_number, bench_number, seat, name, method, code)
      select v_session, s.roll_number, n, s.seat, s.name, 'PASSCODE', public.gen_code()
      from (select coalesce(a.roll_number, b.roll_number) as roll_number) t
      join public.students s on s.roll_number = t.roll_number;
    else
      v_status := 'PENDING';
      v_method := (case when random() < 0.5 then 'QR' else 'PASSCODE' end)::public.verification_method;
      insert into public.session_slots (session_id, roll_number, bench_number, seat, name, method, code) values
        (v_session, a.roll_number, n, 'A', a.name, v_method, public.gen_code()),
        (v_session, b.roll_number, n, 'B', b.name, v_method, public.gen_code());
    end if;
    insert into public.session_benches (session_id, bench_number, status) values (v_session, n, v_status);
  end loop;

  perform public.log_activity('Session started: ' || v_class.name || ' · ' || trim(p_subject));
  return v_session;
end $$;
revoke execute on function public.app_start_session(text, text, int, int) from anon;

create or replace function public.close_session(p_session uuid)
returns void language plpgsql volatile security definer set search_path = public as $$
declare s public.sessions; slot record;
begin
  select * into s from public.sessions where id = p_session and active for update;
  if not found then return; end if;
  for slot in select * from public.session_slots where session_id = p_session loop
    if not exists (select 1 from public.attendance_records where session_id = p_session and roll_number = slot.roll_number) then
      perform public.finalize_attendance(p_session, slot.roll_number, slot.name, slot.bench_number, 'ABSENT', false);
    end if;
  end loop;
  update public.sessions set active = false, ended_at = now() where id = p_session;
  perform public.log_activity('Session ended: ' || s.class_name || ' · ' || s.subject);
end $$;
revoke execute on function public.close_session(uuid) from anon, authenticated;

create or replace function public.app_end_session(p_session uuid)
returns void language plpgsql volatile security definer set search_path = public as $$
begin
  perform public.require_staff('teacher');
  if not exists (select 1 from public.sessions where id = p_session and active) then
    raise exception 'No matching active session';
  end if;
  perform public.close_session(p_session);
end $$;
revoke execute on function public.app_end_session(uuid) from anon;

create or replace function public.app_cancel_session(p_session uuid)
returns void language plpgsql volatile security definer set search_path = public as $$
begin
  perform public.require_staff('teacher');
  if not exists (select 1 from public.sessions where id = p_session and active) then
    raise exception 'No matching active session';
  end if;
  delete from public.sessions where id = p_session;
  perform public.log_activity('Session cancelled (not saved)');
end $$;
revoke execute on function public.app_cancel_session(uuid) from anon;

create or replace function public.app_extend_timer(p_session uuid, p_minutes int)
returns void language plpgsql volatile security definer set search_path = public as $$
begin
  perform public.require_staff('teacher');
  if p_minutes < 1 or p_minutes > 30 then raise exception 'Extension must be between 1 and 30 minutes'; end if;
  update public.sessions set duration_seconds = duration_seconds + p_minutes * 60
    where id = p_session and active;
  if not found then raise exception 'No matching active session'; end if;
  perform public.log_activity('Timer extended by ' || p_minutes || ' min');
end $$;
revoke execute on function public.app_extend_timer(uuid, int) from anon;

create or replace function public.app_set_bench_status(p_session uuid, p_bench int, p_status text)
returns void language plpgsql volatile security definer set search_path = public as $$
declare v_target public.bench_status; slot record;
begin
  perform public.require_staff('teacher');
  if not exists (select 1 from public.sessions where id = p_session and active) then
    raise exception 'No matching active session';
  end if;
  if not exists (select 1 from public.session_benches where session_id = p_session and bench_number = p_bench) then
    raise exception 'Unknown bench: %', p_bench;
  end if;
  if upper(coalesce(p_status,'')) not in ('EMPTY','SINGLE','PRESENT') then
    raise exception 'Status must be EMPTY, SINGLE, or PRESENT';
  end if;
  v_target := upper(p_status)::public.bench_status;

  if v_target = 'EMPTY' then
    for slot in select * from public.session_slots where session_id = p_session and bench_number = p_bench loop
      perform public.finalize_attendance(p_session, slot.roll_number, slot.name, p_bench, 'ABSENT', false);
    end loop;
    perform public.log_activity('Bench ' || p_bench || ' marked empty by teacher');
  elsif v_target = 'SINGLE' then
    perform public.log_activity('Bench ' || p_bench || ' marked single-occupant by teacher');
  else
    for slot in select * from public.session_slots where session_id = p_session and bench_number = p_bench loop
      update public.session_slots set verified = true
        where session_id = p_session and roll_number = slot.roll_number;
      perform public.finalize_attendance(p_session, slot.roll_number, slot.name, p_bench, 'PRESENT', false);
    end loop;
    perform public.log_activity('Bench ' || p_bench || ' force-marked present by teacher');
  end if;

  update public.session_benches set status = v_target where session_id = p_session and bench_number = p_bench;
end $$;
revoke execute on function public.app_set_bench_status(uuid, int, text) from anon;

create or replace function public.app_mark_late(p_session uuid, p_roll text)
returns void language plpgsql volatile security definer set search_path = public as $$
declare st public.students;
begin
  perform public.require_staff('teacher');
  if not exists (select 1 from public.sessions where id = p_session and active) then
    raise exception 'No matching active session';
  end if;
  select * into st from public.students where lower(roll_number) = lower(trim(p_roll));
  if not found then raise exception 'Student not found: %', p_roll; end if;
  perform public.finalize_attendance(p_session, st.roll_number, st.name, st.bench_number, 'LATE', false);
  perform public.log_activity('Late entry: ' || st.name || ' (' || st.roll_number || ')');
end $$;
revoke execute on function public.app_mark_late(uuid, text) from anon;

create or replace function public.app_close_expired_sessions()
returns int language plpgsql volatile security definer set search_path = public as $$
declare s record; c int := 0;
begin
  for s in select id from public.sessions
    where active and started_at + (duration_seconds || ' seconds')::interval <= now() loop
    perform public.close_session(s.id);
    c := c + 1;
  end loop;
  return c;
end $$;
revoke execute on function public.app_close_expired_sessions() from anon;