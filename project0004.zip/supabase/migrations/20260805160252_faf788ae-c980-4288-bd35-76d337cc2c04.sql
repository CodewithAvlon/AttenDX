-- ============ enums ============
create type public.app_role as enum ('teacher','student','admin','principal');
create type public.attendance_status as enum ('PRESENT','LATE','ABSENT');
create type public.bench_status as enum ('PENDING','PARTIAL','PRESENT','SINGLE','EMPTY');
create type public.verification_method as enum ('PASSCODE','QR');

-- ============ identity ============
create table public.profiles (
  id uuid primary key,
  login_id text not null unique,
  display_name text not null,
  created_at timestamptz not null default now()
);
grant select on public.profiles to authenticated;
grant all on public.profiles to service_role;
alter table public.profiles enable row level security;
create policy "own profile readable" on public.profiles for select to authenticated using (id = auth.uid());

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  role public.app_role not null,
  unique (user_id, role)
);
grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;
alter table public.user_roles enable row level security;
create policy "own roles readable" on public.user_roles for select to authenticated using (user_id = auth.uid());

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

-- ============ roster ============
create table public.classes (
  id text primary key,
  name text not null
);
grant select on public.classes to authenticated;
grant all on public.classes to service_role;
alter table public.classes enable row level security;
create policy "classes readable" on public.classes for select to authenticated using (true);

create table public.staff_accounts (
  login_id text primary key,
  display_name text not null,
  role public.app_role not null,
  user_id uuid unique
);
grant select on public.staff_accounts to authenticated;
grant all on public.staff_accounts to service_role;
alter table public.staff_accounts enable row level security;
create policy "own staff row" on public.staff_accounts for select to authenticated using (user_id = auth.uid());

create table public.students (
  roll_number text primary key,
  name text not null,
  class_id text not null references public.classes(id) on delete cascade,
  bench_number int not null check (bench_number > 0),
  seat char(1) not null check (seat in ('A','B')),
  partner_roll text,
  user_id uuid unique
);
create index students_class_idx on public.students (class_id, bench_number);
grant select on public.students to authenticated;
grant all on public.students to service_role;
alter table public.students enable row level security;
create policy "own student row" on public.students for select to authenticated using (user_id = auth.uid());
create policy "staff read students" on public.students for select to authenticated using (
  public.has_role(auth.uid(),'teacher') or public.has_role(auth.uid(),'admin') or public.has_role(auth.uid(),'principal')
);

create table public.bench_layouts (
  class_id text primary key references public.classes(id) on delete cascade,
  grid_rows int not null check (grid_rows between 1 and 12),
  grid_cols int not null check (grid_cols between 1 and 12),
  cells jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);
grant select on public.bench_layouts to authenticated;
grant all on public.bench_layouts to service_role;
alter table public.bench_layouts enable row level security;
create policy "layouts readable" on public.bench_layouts for select to authenticated using (true);

-- ============ sessions ============
create table public.sessions (
  id uuid primary key default gen_random_uuid(),
  class_id text not null references public.classes(id) on delete cascade,
  class_name text not null,
  subject text not null,
  teacher_login text not null,
  teacher_name text not null,
  total_benches int not null check (total_benches between 1 and 60),
  duration_seconds int not null check (duration_seconds > 0),
  active boolean not null default true,
  started_at timestamptz not null default now(),
  ended_at timestamptz
);
create unique index sessions_one_active_per_class on public.sessions (class_id) where active;
create index sessions_started_idx on public.sessions (started_at desc);
grant select on public.sessions to authenticated;
grant all on public.sessions to service_role;
alter table public.sessions enable row level security;
create policy "sessions readable" on public.sessions for select to authenticated using (true);

create table public.session_benches (
  session_id uuid not null references public.sessions(id) on delete cascade,
  bench_number int not null,
  status public.bench_status not null,
  primary key (session_id, bench_number)
);
grant select on public.session_benches to authenticated;
grant all on public.session_benches to service_role;
alter table public.session_benches enable row level security;
create policy "bench status readable" on public.session_benches for select to authenticated using (true);

-- codes live here; deliberately NO client policies. Reached only via security-definer functions.
create table public.session_slots (
  session_id uuid not null references public.sessions(id) on delete cascade,
  roll_number text not null,
  bench_number int not null,
  seat char(1) not null,
  name text not null,
  method public.verification_method not null,
  code text not null,
  entered boolean not null default false,
  verified boolean not null default false,
  failed_attempts int not null default 0,
  primary key (session_id, roll_number)
);
create index session_slots_bench_idx on public.session_slots (session_id, bench_number);
grant all on public.session_slots to service_role;
alter table public.session_slots enable row level security;

create table public.attendance_records (
  session_id uuid not null references public.sessions(id) on delete cascade,
  roll_number text not null,
  name text not null,
  bench_number int not null,
  status public.attendance_status not null,
  verified_by_partner boolean not null default false,
  recorded_at timestamptz not null default now(),
  primary key (session_id, roll_number)
);
create index attendance_roll_idx on public.attendance_records (roll_number);
grant select on public.attendance_records to authenticated;
grant all on public.attendance_records to service_role;
alter table public.attendance_records enable row level security;
create policy "staff read attendance" on public.attendance_records for select to authenticated using (
  public.has_role(auth.uid(),'teacher') or public.has_role(auth.uid(),'admin') or public.has_role(auth.uid(),'principal')
);
create policy "own attendance" on public.attendance_records for select to authenticated using (
  roll_number = (select roll_number from public.students where user_id = auth.uid())
);

create table public.activity_log (
  id bigserial primary key,
  message text not null,
  created_at timestamptz not null default now()
);
grant select on public.activity_log to authenticated;
grant all on public.activity_log to service_role;
alter table public.activity_log enable row level security;
create policy "staff read activity" on public.activity_log for select to authenticated using (
  public.has_role(auth.uid(),'teacher') or public.has_role(auth.uid(),'admin') or public.has_role(auth.uid(),'principal')
);

-- ============ seed roster ============
insert into public.classes (id, name) values
  ('cse-s3-a','CSE - Semester 3 - A'),
  ('cse-s3-b','CSE - Semester 3 - B'),
  ('cse-s5-a','CSE - Semester 5 - A'),
  ('mech-s1-a','MECH - Semester 1 - A');

insert into public.students (roll_number, name, class_id, bench_number, seat, partner_roll) values
  ('2024CS001','Aarav Sharma','cse-s3-a',1,'A','2024CS002'),
  ('2024CS002','Priya Patel','cse-s3-a',1,'B','2024CS001'),
  ('2024CS003','Rohit Desai','cse-s3-a',2,'A','2024CS004'),
  ('2024CS004','Sneha Joshi','cse-s3-a',2,'B','2024CS003'),
  ('2024CS005','Arjun Kulkarni','cse-s3-a',3,'A','2024CS006'),
  ('2024CS006','Kavya Reddy','cse-s3-a',3,'B','2024CS005');

insert into public.staff_accounts (login_id, display_name, role) values
  ('TCH001','Prof. Sharma','teacher'),
  ('admin','Administrator','admin'),
  ('PRIN001','Dr. Mehta','principal');

insert into public.bench_layouts (class_id, grid_rows, grid_cols, cells) values
  ('cse-s3-a', 2, 2, '[{"row":0,"col":0,"benchNumber":1},{"row":0,"col":1,"benchNumber":2},{"row":1,"col":0,"benchNumber":3}]'::jsonb);