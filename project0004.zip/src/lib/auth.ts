import { useQuery } from "@tanstack/react-query";

import { supabase } from "@/integrations/supabase/client";
import { api, type Me } from "@/lib/attendx";

export function loginEmail(loginId: string) {
  return `${loginId.trim().toLowerCase().replace(/[^a-z0-9]/g, "")}@attendx.app`;
}

export async function signInWithId(loginId: string, password: string) {
  const { error } = await supabase.auth.signInWithPassword({
    email: loginEmail(loginId),
    password,
  });
  if (error) {
    throw new Error(
      error.message.toLowerCase().includes("invalid")
        ? "Incorrect ID or password. If this is your first time, use Create access."
        : error.message,
    );
  }
  return api.claim(loginId);
}

export async function registerWithId(loginId: string, password: string) {
  const { error } = await supabase.auth.signUp({
    email: loginEmail(loginId),
    password,
  });
  if (error) {
    const m = error.message.toLowerCase();
    if (m.includes("already registered") || m.includes("already exists") || m.includes("user already")) {
      return signInWithId(loginId, password);
    }
    throw new Error(error.message);
  }

  return api.claim(loginId);
}

export async function signOut() {
  await supabase.auth.signOut();
}

export function useMe() {
  return useQuery<Me | null>({
    queryKey: ["me"],
    queryFn: api.me,
    staleTime: 60_000,
    retry: false,
  });
}
