import { supabase } from "@/integrations/supabase/client";

type RpcResult = { data: unknown; error: { message: string } | null };
type RpcClient = {
  rpc: (fn: string, args?: Record<string, unknown>) => PromiseLike<RpcResult>;
};

const db = supabase as unknown as RpcClient;

export async function rpc<T>(fn: string, args?: Record<string, unknown>): Promise<T> {
  const { data, error } = await db.rpc(fn, args ?? {});
  if (error) throw new Error(cleanMessage(error.message));
  return data as T;
}

function cleanMessage(message: string) {
  return message.replace(/^.*?:\s*/, (match) => (match.includes("error") ? "" : match)).trim();
}

/* ---------------- shared types ---------------- */

export type Role = "student" | "teacher" | "admin" | "principal";
export type BenchStatus = "PENDING" | "PARTIAL" | "PRESENT" | "SINGLE" | "EMPTY";
export type AttendanceStatus = "PRESENT" | "LATE" | "ABSENT";

export type Me = {
  loginId: string;
  name: string;
  role: Role;
  rollNumber?: string;
  classId?: string;
  className?: string;
};

export type LayoutCell = { row: number; col: number; benchNumber: number };
export type Layout = { rows: number; cols: number; cells: LayoutCell[] } | null;

export type ActiveStudentSession = {
      active: true;
      sessionId: string;
      subject: string;
      className: string;
      teacherName: string;
      totalBenches: number;
      myBench: number | null;
      mySeat: "A" | "B" | null;
      remainingSeconds: number;
      benchStatus?: BenchStatus;
      seated: boolean;
      layout: Layout;
      benches: {
        benchNumber: number;
        status: BenchStatus;
        seats: { seat: "A" | "B"; name: string; verified: boolean; mine: boolean }[];
      }[];
      method?: "QR" | "PASSCODE";
      myCode?: string;
      entered?: boolean;
      verified?: boolean;
      failedAttempts?: number;
      attemptsLeft?: number;
      locked?: boolean;
      partnerName?: string | null;
      partnerVerified?: boolean;
      status?: AttendanceStatus | null;
      lastResult?: "VERIFIED" | "INCORRECT";
    };

export type StudentSession = { active: false } | ActiveStudentSession;

export type SessionSlotView = {
  rollNumber: string;
  name: string;
  seat: "A" | "B";
  method: "QR" | "PASSCODE";
  entered: boolean;
  verified: boolean;
  failedAttempts: number;
};

export type SessionView = {
  sessionId: string;
  classId: string;
  className: string;
  subject: string;
  teacherName: string;
  totalBenches: number;
  active: boolean;
  startedAt: string;
  endedAt: string | null;
  remainingSeconds: number;
  layout: Layout;
  benches: { benchNumber: number; status: BenchStatus; students: SessionSlotView[] }[];
  counts: { present: number; late: number; absent: number };
  seatedCount: number;
  verifiedCount: number;
};

export type TeacherHome = {
  teacherName: string;
  classes: { id: string; name: string; studentCount: number; liveSessionId: string | null }[];
  mySessions: {
    id: string;
    className: string;
    subject: string;
    active: boolean;
    startedAt: string;
    present: number;
    total: number;
  }[];
};

export type AdminHome = {
  classes: { id: string; name: string; studentCount: number; layout: Layout }[];
  students: {
    rollNumber: string;
    name: string;
    classId: string;
    registered: boolean;
    sessionsCounted: number;
    presentCount: number;
  }[];
  staff: { loginId: string; name: string; role: Role; registered: boolean }[];
  sessions: {
    id: string;
    className: string;
    subject: string;
    teacherName: string;
    active: boolean;
    startedAt: string;
  }[];
  activity: { message: string; at: string }[];
};

export type PrincipalHome = {
  totals: {
    classes: number;
    students: number;
    staff: number;
    liveSessions: number;
    sessionsToday: number;
    attendanceRate: number;
  };
  liveSessions: {
    id: string;
    className: string;
    subject: string;
    teacherName: string;
    startedAt: string;
    verified: number;
    seated: number;
  }[];
  recentSessions: {
    id: string;
    className: string;
    subject: string;
    teacherName: string;
    startedAt: string;
    active: boolean;
    present: number;
    total: number;
  }[];
  activity: { message: string; at: string }[];
};

export type SessionReport = {
  className: string;
  subject: string;
  teacherName: string;
  startedAt: string;
  endedAt: string | null;
  rows: {
    rollNumber: string;
    name: string;
    benchNumber: number;
    status: AttendanceStatus;
    verifiedByPartner: boolean;
    recordedAt: string;
  }[];
};

export type PastSession = {
  sessionId: string;
  className: string;
  subject: string;
  teacherName: string;
  startedAt: string;
  endedAt: string | null;
  benches: {
    benchNumber: number;
    status: BenchStatus;
    students: { name: string; rollNumber: string; status: AttendanceStatus }[];
  }[];
  singleBenches: { benchNumber: number; students: string[] }[];
  emptyBenches: number[];
  absentees: { rollNumber: string; name: string; benchNumber: number }[];
};

export type PreviousSession = PastSession | null;

export type TimetableEntry = {
  id: string;
  teacherLogin: string;
  teacherName: string | null;
  classId: string;
  className: string;
  subject: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
};

export type ScheduleSlot = {
  id: string;
  classId: string;
  className: string;
  subject: string;
  startTime: string;
  endTime: string;
  current?: boolean;
};

export type MySchedule = {
  dayOfWeek: number;
  localTime: string;
  today: ScheduleSlot[];
  current: ScheduleSlot | null;
  next: ScheduleSlot | null;
};

export type TimetableInput = {
  teacherLogin: string;
  classId: string;
  subject: string;
  dayOfWeek: number;
  startTime: string;
  endTime: string;
};

export const DAY_NAMES = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export type HistoryEntry = {
  date: string;
  status: AttendanceStatus;
  subject: string;
  className: string;
  benchNumber: number;
};

export type LateBoard = {
  students: { rollNumber: string; name: string; pending: boolean }[];
  pending: { rollNumber: string; name: string; markedBy: string; markedAt: string }[];
  recent: { rollNumber: string; name: string; markedBy: string; markedAt: string }[];
};



/* ---------------- api ---------------- */

export const api = {
  me: () => rpc<Me | null>("app_me"),
  claim: (loginId: string) => rpc<{ role: Role }>("claim_account", { p_login_id: loginId }),

  studentSession: () => rpc<StudentSession>("app_student_session"),
  checkIn: (bench: number) => rpc<StudentSession>("app_check_in", { p_bench: bench }),
  verify: (code: string) => rpc<StudentSession>("app_verify_partner", { p_code: code }),
  myHistory: () => rpc<HistoryEntry[]>("app_my_history"),

  teacherHome: () => rpc<TeacherHome>("app_teacher_home"),
  startSession: (classId: string, subject: string, minutes = 5) =>
    rpc<string>("app_start_session", {
      p_class_id: classId,
      p_subject: subject,
      p_timer_minutes: minutes,
    }),
  sessionView: (sessionId: string) => rpc<SessionView>("app_session_view", { p_session: sessionId }),
  endSession: (sessionId: string) => rpc<void>("app_end_session", { p_session: sessionId }),
  cancelSession: (sessionId: string) => rpc<void>("app_cancel_session", { p_session: sessionId }),
  extendTimer: (sessionId: string, minutes: number) =>
    rpc<void>("app_extend_timer", { p_session: sessionId, p_minutes: minutes }),
  setBenchStatus: (sessionId: string, bench: number, status: "EMPTY" | "SINGLE" | "PRESENT") =>
    rpc<void>("app_set_bench_status", { p_session: sessionId, p_bench: bench, p_status: status }),
  markLate: (sessionId: string, roll: string) =>
    rpc<void>("app_mark_late", { p_session: sessionId, p_roll: roll }),
  previousSession: (classId: string) =>
    rpc<PreviousSession>("app_class_previous_session", { p_class_id: classId }),
  todaySessions: (classId: string) =>
    rpc<PastSession[]>("app_class_today_sessions", { p_class_id: classId }),

  lateBoard: (classId: string) => rpc<LateBoard>("app_late_board", { p_class_id: classId }),
  markLateEntry: (classId: string, roll: string) =>
    rpc<void>("app_mark_late_entry", { p_class_id: classId, p_roll: roll }),
  clearLateEntry: (classId: string, roll: string) =>
    rpc<void>("app_clear_late_entry", { p_class_id: classId, p_roll: roll }),

  mySchedule: () => rpc<MySchedule>("app_my_schedule"),


  adminHome: () => rpc<AdminHome>("app_admin_home"),
  timetable: () => rpc<TimetableEntry[]>("app_timetable_all"),
  saveTimetable: (entries: TimetableInput[], replace = false) =>
    rpc<{ saved: number }>("app_save_timetable", { p_entries: entries, p_replace: replace }),
  deleteTimetableEntry: (id: string) => rpc<void>("app_delete_timetable_entry", { p_id: id }),
  saveLayout: (classId: string, rows: number, cols: number, cells: LayoutCell[]) =>
    rpc<void>("app_save_layout", {
      p_class_id: classId,
      p_rows: rows,
      p_cols: cols,
      p_cells: cells,
    }),
  upsertStudent: (s: { roll: string; name: string; classId: string }) =>
    rpc<void>("app_upsert_student", {
      p_roll: s.roll,
      p_name: s.name,
      p_class_id: s.classId,
    }),
  deleteStudent: (roll: string) => rpc<void>("app_delete_student", { p_roll: roll }),
  upsertStaff: (loginId: string, name: string, role: string) =>
    rpc<void>("app_upsert_staff", { p_login: loginId, p_name: name, p_role: role }),
  deleteStaff: (loginId: string) => rpc<void>("app_delete_staff", { p_login: loginId }),

  principalHome: () => rpc<PrincipalHome>("app_principal_home"),
  sessionReport: (sessionId: string) => rpc<SessionReport>("app_session_report", { p_session: sessionId }),
};

export function statusTone(status: BenchStatus) {
  switch (status) {
    case "PRESENT":
      return "border-success/50 bg-success/10";
    case "PARTIAL":
      return "border-warning/50 bg-warning/10";
    case "SINGLE":
      return "border-cyan/40 bg-cyan/10";
    case "EMPTY":
      return "border-border opacity-50";
    default:
      return "border-border bg-elevated";
  }
}

export function formatClock(seconds: number) {
  const s = Math.max(0, Math.floor(seconds));
  const m = Math.floor(s / 60);
  return `${String(m).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

export function downloadCsv(filename: string, rows: (string | number)[][]) {
  const csv = rows
    .map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(","))
    .join("\n");
  const url = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}
