import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";


import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { registerWithId, signInWithId } from "@/lib/auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "AttendX — Bench-Pair Attendance for Classrooms" },
      {
        name: "description",
        content:
          "AttendX verifies classroom attendance in pairs: students confirm their bench partner with a rotating passcode or QR code while teachers watch the room fill up live.",
      },
      { property: "og:title", content: "AttendX — Bench-Pair Attendance for Classrooms" },
      {
        property: "og:description",
        content:
          "Partner-verified attendance sessions with live bench grids, timers and instant reports for teachers, admins and principals.",
      },
    ],
  }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"signin" | "register">("signin");
  const [loginId, setLoginId] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  // Until React hydrates, a click would submit the form natively and look like
  // "nothing happens", so keep the button inert for that brief moment.
  const [ready, setReady] = useState(false);
  useEffect(() => setReady(true), []);


  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (!loginId.trim()) throw new Error("Enter your roll number or staff ID.");
      if (password.length < 6) throw new Error("Password needs 6 characters — anything simple works.");
      if (mode === "signin") await signInWithId(loginId, password);
      else await registerWithId(loginId, password);
      await navigate({ to: "/dashboard" });
    } catch (err) {
      const raw = err instanceof Error ? err.message : "Something went wrong.";
      let msg = raw;
      if (/invalid login credentials/i.test(raw) && mode === "signin") {
        msg = "Wrong ID or password. First time on this ID? Use \u201cCreate access\u201d instead.";
      } else if (/already registered|already exists/i.test(raw)) {
        msg = "This ID already has access — switch to \u201cSign in\u201d.";
      } else if (/weak|easy to guess/i.test(raw)) {
        msg = "Try a slightly different password (6+ characters).";
      }
      setError(msg);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-md flex-col justify-center px-5 py-16">
      <header className="text-center">
        <h1 className="font-display text-4xl font-extrabold">
          Attend<span className="text-cyan">X</span>
        </h1>
        <p className="mt-2 text-sm tracking-wide text-muted-foreground">
          Partner-verified classroom attendance
        </p>
      </header>

      <div className="glass mt-8 rounded-2xl p-6 shadow-panel">
        <div className="mb-6 flex gap-1 rounded-xl bg-surface p-1">
          {(["signin", "register"] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => {
                setMode(m);
                setError(null);
              }}
              className={`flex-1 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                mode === m
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {m === "signin" ? "Sign in" : "Create access"}
            </button>
          ))}
        </div>

        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="loginId">Roll number or staff ID</Label>
            <Input
              id="loginId"
              value={loginId}
              autoCapitalize="characters"
              onChange={(e) => setLoginId(e.target.value)}
              placeholder="2024CS001"
              maxLength={40}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="6+ characters, e.g. 123456"
              maxLength={72}
            />
          </div>

          {error ? <p className="text-sm text-destructive">{error}</p> : null}

          <Button type="submit" disabled={busy || !ready} className="w-full">
            {busy ? "Please wait…" : mode === "signin" ? "Sign in" : "Create access"}
          </Button>

        </form>

        <p className="mt-5 text-center text-xs leading-relaxed text-subtle">
          Your role comes from the institution roster. Sample IDs: student{" "}
          <span className="text-muted-foreground">2024CS001</span>, teacher{" "}
          <span className="text-muted-foreground">TCH001</span>, admin{" "}
          <span className="text-muted-foreground">admin</span>, principal{" "}
          <span className="text-muted-foreground">PRIN001</span>.
        </p>
      </div>
    </main>
  );
}
