import { createFileRoute } from "@tanstack/react-router";

import { AdminPanel } from "@/components/AdminPanel";
import { PrincipalPanel } from "@/components/PrincipalPanel";
import { StudentPanel } from "@/components/StudentPanel";
import { TeacherPanel } from "@/components/TeacherPanel";
import { Button } from "@/components/ui/button";
import { signOut, useMe } from "@/lib/auth";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Dashboard — AttendX" },
      {
        name: "description",
        content:
          "Your AttendX workspace: run partner-verified attendance sessions, watch the live bench grid and review attendance records.",
      },
      { property: "og:title", content: "Dashboard — AttendX" },
      {
        property: "og:description",
        content: "Run and review partner-verified classroom attendance sessions in AttendX.",
      },
    ],
  }),
  component: Dashboard,
});

function Dashboard() {
  const me = useMe();

  if (me.isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <div className="animate-pulse-ring h-3.5 w-3.5 rounded-full bg-primary" />
      </div>
    );
  }

  if (!me.data) {
    return (
      <div className="mx-auto flex min-h-screen max-w-md flex-col items-center justify-center gap-4 px-5 text-center">
        <h1 className="font-display text-xl font-bold">Account not linked</h1>
        <p className="text-sm text-muted-foreground">
          This login is not connected to a roster entry yet. Sign in again with your roll number or
          staff ID.
        </p>
        <Button onClick={() => void signOut().then(() => window.location.replace("/"))}>
          Back to sign in
        </Button>
      </div>
    );
  }

  const me_ = me.data;
  switch (me_.role) {
    case "student":
      return <StudentPanel me={me_} />;
    case "teacher":
      return <TeacherPanel me={me_} />;
    case "admin":
      return <AdminPanel me={me_} />;
    case "principal":
      return <PrincipalPanel me={me_} />;
    default:
      return null;
  }
}
