import type { BenchStatus, Layout } from "@/lib/attendx";

export type BenchSeatState = {
  seat: "A" | "B";
  name?: string;
  verified?: boolean;
  mine?: boolean;
};

export type BenchCellState = {
  benchNumber: number;
  status: BenchStatus;
  seats?: BenchSeatState[];
  label?: string;
};

const rowLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

function initials(name?: string) {
  if (!name) return "";
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((p) => p[0]?.toUpperCase() ?? "")
    .join("");
}

/** One cinema-style seat. */
function Seat({
  seat,
  letter,
  mine,
  onPick,
  clickable,
}: {
  seat: BenchSeatState | undefined;
  letter: "A" | "B";
  mine?: boolean | undefined;
  onPick?: (() => void) | undefined;
  clickable?: boolean | undefined;
}) {
  const taken = Boolean(seat);
  const tone = mine
    ? "border-primary bg-primary text-primary-foreground"
    : seat
      ? seat.verified
        ? "border-success/70 bg-success/25 text-success"
        : "border-warning/70 bg-warning/20 text-warning"
      : "border-border bg-elevated text-subtle";

  return (
    <span
      className="flex flex-col items-center"
      title={seat ? `${letter} · ${seat.name ?? "Occupied"}` : `Seat ${letter} · available`}
    >
      {/* seat back */}
      <span
        className={`flex h-6 w-7 items-end justify-center rounded-t-md border border-b-0 text-[9px] font-bold leading-none transition-all ${tone} ${
          clickable ? "group-hover/bench:-translate-y-0.5 group-hover/bench:border-primary" : ""
        } ${taken && !mine ? "" : ""}`}
      >
        <span className="pb-0.5">{seat ? initials(seat.name) || "•" : letter}</span>
      </span>
      {/* seat base */}
      <span
        className={`h-1.5 w-8 rounded-b-md border border-t-0 ${tone} ${
          clickable ? "group-hover/bench:border-primary" : ""
        }`}
      />
      <span className="mt-0.5 text-[8px] font-semibold uppercase tracking-wide text-subtle">
        {seat ? (seat.verified ? "ok" : "held") : "free"}
      </span>
      {clickable && onPick ? (
        <button
          type="button"
          onClick={onPick}
          className="sr-only"
          aria-label={`Pick bench seat ${letter}`}
        />
      ) : null}
    </span>
  );
}

function Bench({
  bench,
  isMine,
  onSelect,
  disabled,
  label,
}: {
  bench: BenchCellState;
  isMine: boolean;
  onSelect?: ((n: number) => void) | undefined;
  disabled?: boolean | undefined;
  label: string;
}) {
  const seats = bench.seats ?? [];
  const seatA = seats.find((s) => s.seat === "A");
  const seatB = seats.find((s) => s.seat === "B");
  const full = seats.length >= 2;
  const clickable = Boolean(onSelect) && !disabled && !full && !isMine;

  return (
    <button
      type="button"
      disabled={!clickable}
      onClick={clickable ? () => onSelect?.(bench.benchNumber) : undefined}
      aria-label={`${label} — ${full ? "full" : clickable ? "available, tap to select" : bench.status.toLowerCase()}`}
      className={`group/bench relative flex flex-col items-center gap-1 rounded-xl px-2 pb-1 pt-1.5 transition-all ${
        clickable ? "cursor-pointer hover:bg-primary/10" : "cursor-default"
      } ${isMine ? "bg-primary/10 ring-1 ring-primary" : ""} ${full && !isMine ? "opacity-60" : ""}`}
    >
      <span className="flex items-end gap-1">
        <Seat seat={seatA} letter="A" mine={isMine && seatA?.mine} clickable={clickable} />
        <span className="mb-3 h-4 w-px rounded bg-border" aria-hidden />
        <Seat seat={seatB} letter="B" mine={isMine && seatB?.mine} clickable={clickable} />
      </span>
      <span className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground">
        {label}
        {isMine ? <span className="ml-1 text-primary">you</span> : null}
      </span>
    </button>
  );
}

function Legend() {
  const items = [
    { label: "Available", cls: "border-border bg-elevated" },
    { label: "Held", cls: "border-warning/70 bg-warning/20" },
    { label: "Verified", cls: "border-success/70 bg-success/25" },
    { label: "You", cls: "border-primary bg-primary" },
  ];
  return (
    <div className="mt-4 flex flex-wrap items-center justify-center gap-4">
      {items.map((i) => (
        <span key={i.label} className="flex items-center gap-1.5 text-[10px] font-semibold uppercase tracking-wide text-subtle">
          <span className={`h-3 w-4 rounded-t-sm border ${i.cls}`} />
          {i.label}
        </span>
      ))}
    </div>
  );
}

function Screen() {
  return (
    <div className="mb-6 flex flex-col items-center">
      <div
        className="h-2.5 w-[min(560px,90%)] rounded-[100%] bg-gradient-to-r from-transparent via-primary to-transparent opacity-80"
        style={{ boxShadow: "0 14px 40px -6px color-mix(in oklab, var(--primary) 55%, transparent)" }}
        aria-hidden
      />
      <span className="mt-2 text-[10px] font-bold uppercase tracking-[0.4em] text-subtle">
        Board · front of class
      </span>
    </div>
  );
}

/**
 * Cinema (PVR-style) seat map for benches: a glowing board "screen" at the front,
 * lettered rows curving away from it, and two cinema seats per bench.
 */
export function BenchLayoutGrid({
  layout,
  benches,
  highlight,
  onSelect,
  disabled,
  showBoard = true,
}: {
  layout: Layout;
  benches: BenchCellState[];
  highlight?: number | null;
  onSelect?: (benchNumber: number) => void;
  disabled?: boolean;
  showBoard?: boolean;
}) {
  const byNumber = new Map(benches.map((b) => [b.benchNumber, b]));

  // Build rows: either from the saved layout, or by chunking benches.
  let rows: (BenchCellState | null)[][];
  if (layout && layout.cells.length > 0) {
    const map = new Map(layout.cells.map((c) => [`${c.row}:${c.col}`, c.benchNumber]));
    rows = Array.from({ length: layout.rows }, (_, r) =>
      Array.from({ length: layout.cols }, (_, c) => {
        const n = map.get(`${r}:${c}`);
        return n ? byNumber.get(n) ?? null : null;
      }),
    );
  } else {
    const perRow = Math.min(6, Math.max(3, Math.ceil(Math.sqrt(benches.length || 1))));
    rows = [];
    for (let i = 0; i < benches.length; i += perRow) rows.push(benches.slice(i, i + perRow));
  }

  const maxDepth = Math.max(rows.length - 1, 1);

  return (
    <div className="rounded-2xl border border-border bg-surface/60 px-3 py-5">
      {showBoard ? <Screen /> : null}

      <div className="overflow-x-auto pb-1">
        <div className="mx-auto flex min-w-fit flex-col items-center gap-2">
          {rows.map((row, rIdx) => {
            const depth = rIdx / maxDepth;
            return (
              <div
                key={rIdx}
                className="flex items-end gap-1.5"
                style={{ transform: `perspective(900px) scale(${1 + depth * 0.06})` }}
              >
                <span className="mr-1 w-4 text-right text-[10px] font-bold text-subtle">
                  {rowLetters[rIdx] ?? rIdx + 1}
                </span>
                {row.map((bench, cIdx) =>
                  bench ? (
                    <Bench
                      key={`${rIdx}-${cIdx}`}
                      bench={bench}
                      isMine={highlight === bench.benchNumber}
                      onSelect={onSelect}
                      disabled={disabled}
                      label={bench.label ?? `${bench.benchNumber}`}
                    />
                  ) : (
                    <span key={`${rIdx}-${cIdx}`} className="w-[86px]" aria-hidden />
                  ),
                )}
                <span className="ml-1 w-4 text-[10px] font-bold text-subtle">
                  {rowLetters[rIdx] ?? rIdx + 1}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      <Legend />
    </div>
  );
}
