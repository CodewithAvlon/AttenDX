import { useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import type { ReactNode } from "react";

import { Button } from "@/components/ui/button";
import { signOut } from "@/lib/auth";

export function Shell({
  title,
  name,
  badge,
  children,
}: {
  title: string;
  name: string;
  badge?: ReactNode;
  children: ReactNode;
}) {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await signOut();
    await navigate({ to: "/", replace: true });
  }

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 flex items-center gap-4 border-b border-border bg-background/70 px-5 py-3.5 backdrop-blur-md sm:px-7">
        <span className="font-display text-lg font-extrabold">
          Attend<span className="text-cyan">X</span>
        </span>
        <span className="hidden h-5 w-px bg-border sm:block" />
        <span className="hidden text-sm font-semibold text-muted-foreground sm:block">{title}</span>
        <div className="ml-auto flex items-center gap-2">
          {badge}
          <span className="hidden rounded-full border border-border bg-card px-3 py-1.5 text-xs text-muted-foreground sm:block">
            {name}
          </span>
          <Button variant="outline" size="sm" onClick={handleSignOut}>
            Sign out
          </Button>
        </div>
      </header>
      <main className="mx-auto w-full max-w-6xl px-5 py-7 pb-16">{children}</main>
    </div>
  );
}

export function SectionHeader({ title, subtitle }: { title: string; subtitle?: string }) {
  return (
    <div className="mb-5">
      <h2 className="font-display text-2xl font-bold">{title}</h2>
      {subtitle ? <p className="mt-1 text-sm text-muted-foreground">{subtitle}</p> : null}
    </div>
  );
}

export function Panel({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return <section className={`panel mb-4 p-5 ${className}`}>{children}</section>;
}

export function Stat({
  value,
  label,
  tone = "default",
}: {
  value: ReactNode;
  label: string;
  tone?: "default" | "green" | "amber" | "red" | "cyan";
}) {
  const tones: Record<string, string> = {
    default: "text-foreground",
    green: "text-success",
    amber: "text-warning",
    red: "text-destructive",
    cyan: "text-cyan",
  };
  return (
    <div className="panel p-4 text-center">
      <div className={`font-display text-3xl font-extrabold ${tones[tone]}`}>{value}</div>
      <div className="mt-1 text-xs text-muted-foreground">{label}</div>
    </div>
  );
}

export function ErrorNote({ error }: { error: unknown }) {
  if (!error) return null;
  return (
    <p className="mb-3 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
      {error instanceof Error ? error.message : String(error)}
    </p>
  );
}
