type Entry = { message: string; at: string };

function dayLabel(d: Date) {
  const today = new Date();
  const startOf = (x: Date) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((startOf(today) - startOf(d)) / 86400000);
  if (diff === 0) return "Today";
  if (diff === 1) return "Yesterday";
  return d.toLocaleDateString(undefined, {
    weekday: "short",
    day: "numeric",
    month: "short",
    year: d.getFullYear() === today.getFullYear() ? undefined : "numeric",
  });
}

export function ActivityFeed({
  entries,
  dotClass = "bg-primary",
  className = "",
}: {
  entries: Entry[];
  dotClass?: string;
  className?: string;
}) {
  if (!entries.length) {
    return <p className="text-sm text-muted-foreground">No activity yet.</p>;
  }

  const groups: { key: string; label: string; items: Entry[] }[] = [];
  for (const entry of [...entries].sort(
    (a, b) => new Date(b.at).getTime() - new Date(a.at).getTime(),
  )) {
    const date = new Date(entry.at);
    const key = date.toDateString();
    let group = groups.find((g) => g.key === key);
    if (!group) {
      group = { key, label: dayLabel(date), items: [] };
      groups.push(group);
    }
    group.items.push(entry);
  }

  return (
    <div className={`space-y-4 ${className}`}>
      {groups.map((group) => (
        <section key={group.key}>
          <div className="mb-2 flex items-center gap-3">
            <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              {group.label}
            </h4>
            <span className="rounded-full bg-muted px-2 py-0.5 text-[11px] text-subtle">
              {group.items.length}
            </span>
            <span className="h-px flex-1 bg-border" />
          </div>
          <ul className="space-y-2 text-sm">
            {group.items.map((a, i) => (
              <li key={i} className="flex items-start gap-3">
                <span className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${dotClass}`} />
                <span className="flex-1">{a.message}</span>
                <span className="shrink-0 text-xs text-subtle">
                  {new Date(a.at).toLocaleTimeString()}
                </span>
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}
