import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";

import { BenchLayoutGrid } from "@/components/BenchLayoutGrid";
import { StatusPill } from "@/components/StudentPanel";
import { ErrorNote, Panel, SectionHeader, Shell, Stat } from "@/components/Shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  api,
  downloadCsv,
  formatClock,
  statusTone,
  type Me,
  type SessionView,
} from "@/lib/attendx";

export function TeacherPanel({ me }: { me: Me }) {
  const queryClient = useQueryClient();
  const [sessionId, setSessionId] = useState<string | null>(null);

  const home = useQuery({ queryKey: ["teacher-home"], queryFn: api.teacherHome, refetchInterval: 15000 });

  useEffect(() => {
    if (sessionId) return;
    const liveClass = home.data?.classes.find((c) => c.liveSessionId);
    if (liveClass?.liveSessionId) setSessionId(liveClass.liveSessionId);
  }, [home.data, sessionId]);

  const view = useQuery({
    queryKey: ["session-view", sessionId],
    queryFn: () => api.sessionView(sessionId as string),
    enabled: Boolean(sessionId),
    refetchInterval: 4000,
  });

  return (
    <Shell
      title="Teacher"
      name={me.name}
      badge={
        view.data?.active ? (
          <span className="flex items-center gap-2 rounded-full border border-success/40 bg-success/10 px-3 py-1.5 text-xs text-success">
            <span className="animate-live-dot h-2 w-2 rounded-full bg-destructive" />
            Live
          </span>
        ) : null
      }
    >
      <ErrorNote error={home.error ?? view.error} />

      {sessionId && view.data ? (
        <LiveSession
          view={view.data}
          onLeave={() => {
            setSessionId(null);
            void queryClient.invalidateQueries({ queryKey: ["teacher-home"] });
          }}
        />
      ) : (
        <StartSession
          classes={home.data?.classes ?? []}
          onStarted={(id) => {
            setSessionId(id);
            void queryClient.invalidateQueries({ queryKey: ["teacher-home"] });
          }}
        />
      )}

      <LateEntryBoard
        classes={home.data?.classes ?? []}
        defaultClassId={view.data?.classId ?? home.data?.classes[0]?.id ?? ""}
      />



      <Panel>
        <h3 className="mb-3 text-base font-semibold">My recent sessions</h3>
        {home.data?.mySessions.length ? (
          <ul className="divide-y divide-border text-sm">
            {home.data.mySessions.map((s) => (
              <li key={s.id} className="flex items-center justify-between gap-3 py-2.5">
                <span>
                  <span className="font-medium">{s.subject}</span>
                  <span className="text-muted-foreground"> · {s.className}</span>
                  <span className="block text-xs text-subtle">
                    {new Date(s.startedAt).toLocaleString()} · {s.present}/{s.total} present
                  </span>
                </span>
                <span className="flex items-center gap-2">
                  {s.active ? (
                    <span className="rounded-full border border-success/40 bg-success/10 px-2.5 py-1 text-[11px] text-success">
                      LIVE
                    </span>
                  ) : null}
                  <Button variant="outline" size="sm" onClick={() => setSessionId(s.id)}>
                    Open
                  </Button>
                </span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted-foreground">No sessions yet.</p>
        )}
      </Panel>
    </Shell>
  );
}

function LateEntryBoard({
  classes,
  defaultClassId,
}: {
  classes: { id: string; name: string; studentCount: number; liveSessionId: string | null }[];
  defaultClassId: string;
}) {
  const queryClient = useQueryClient();
  const [classId, setClassId] = useState(defaultClassId);
  const [search, setSearch] = useState("");

  useEffect(() => {
    if (!classId && defaultClassId) setClassId(defaultClassId);
  }, [defaultClassId, classId]);

  const board = useQuery({
    queryKey: ["late-board", classId],
    queryFn: () => api.lateBoard(classId),
    enabled: Boolean(classId),
    refetchInterval: 10000,
  });

  const refresh = () => {
    void queryClient.invalidateQueries({ queryKey: ["late-board", classId] });
    void queryClient.invalidateQueries({ queryKey: ["session-view"] });
  };

  const mark = useMutation({
    mutationFn: (roll: string) => api.markLateEntry(classId, roll),
    onSuccess: refresh,
  });
  const clear = useMutation({
    mutationFn: (roll: string) => api.clearLateEntry(classId, roll),
    onSuccess: refresh,
  });

  const students = (board.data?.students ?? []).filter((s) => {
    const q = search.trim().toLowerCase();
    return !q || s.name.toLowerCase().includes(q) || s.rollNumber.toLowerCase().includes(q);
  });
  const pending = board.data?.pending ?? [];

  return (
    <Panel className="mb-6">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className="text-base font-semibold">Late entries</h3>
          <p className="text-xs text-muted-foreground">
            Mark late arrivals any time — before, during or after the attendance session. They still
            verify with their bench partner, but the record shows LATE for that lecture.
          </p>
        </div>
        <select
          value={classId}
          onChange={(e) => setClassId(e.target.value)}
          className="h-10 rounded-lg border border-input bg-surface px-3 text-sm text-foreground outline-none focus:border-primary"
        >
          {classes.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </div>

      <ErrorNote error={board.error ?? mark.error ?? clear.error} />

      {pending.length ? (
        <div className="mb-4 rounded-xl border border-warning/40 bg-warning/10 p-3">
          <p className="mb-2 text-xs uppercase tracking-wide text-warning">
            Waiting to apply to the next / current lecture
          </p>
          <ul className="flex flex-wrap gap-2">
            {pending.map((p) => (
              <li
                key={p.rollNumber}
                className="flex items-center gap-2 rounded-full border border-warning/40 px-3 py-1 text-xs"
              >
                <span className="font-medium">{p.name}</span>
                <span className="text-subtle">{p.rollNumber}</span>
                <button
                  type="button"
                  className="text-destructive"
                  onClick={() => clear.mutate(p.rollNumber)}
                >
                  ✕
                </button>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      <Input
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        placeholder="Search student by name or roll number"
        className="mb-3"
      />

      <ul className="max-h-72 divide-y divide-border overflow-y-auto text-sm">
        {students.map((s) => (
          <li key={s.rollNumber} className="flex items-center justify-between gap-3 py-2">
            <span>
              <span className="font-medium">{s.name}</span>
              <span className="block text-xs text-subtle">{s.rollNumber}</span>
            </span>
            {s.pending ? (
              <Button
                variant="outline"
                size="sm"
                disabled={clear.isPending}
                onClick={() => clear.mutate(s.rollNumber)}
              >
                Undo late
              </Button>
            ) : (
              <Button
                variant="outline"
                size="sm"
                disabled={mark.isPending}
                onClick={() => mark.mutate(s.rollNumber)}
              >
                Mark late entry
              </Button>
            )}
          </li>
        ))}
        {students.length === 0 ? (
          <li className="py-2 text-sm text-muted-foreground">No students found.</li>
        ) : null}
      </ul>

      {board.data?.recent.length ? (
        <div className="mt-4">
          <p className="mb-2 text-xs uppercase tracking-wide text-muted-foreground">
            Recently recorded as late
          </p>
          <ul className="text-xs text-subtle">
            {board.data.recent.map((r, i) => (
              <li key={`${r.rollNumber}-${i}`}>
                {r.name} ({r.rollNumber}) · {new Date(r.markedAt).toLocaleString()} · by {r.markedBy}
              </li>
            ))}
          </ul>
        </div>
      ) : null}
    </Panel>
  );
}



function StartSession({
  classes,
  onStarted,
}: {
  classes: { id: string; name: string; studentCount: number; liveSessionId: string | null }[];
  onStarted: (sessionId: string) => void;
}) {
  const [classId, setClassId] = useState("");
  const [subject, setSubject] = useState("");
  const [autofilled, setAutofilled] = useState<string | null>(null);

  const schedule = useQuery({
    queryKey: ["my-schedule"],
    queryFn: api.mySchedule,
    refetchInterval: 60000,
  });
  const slot = schedule.data?.current ?? schedule.data?.next ?? null;

  useEffect(() => {
    if (!slot || autofilled === slot.id) return;
    setAutofilled(slot.id);
    setClassId(slot.classId);
    setSubject(slot.subject);
  }, [slot, autofilled]);

  useEffect(() => {
    if (!classId && !slot && classes.length) setClassId(classes[0]!.id);
  }, [classes, classId, slot]);

  const start = useMutation({
    mutationFn: () => api.startSession(classId, subject),
    onSuccess: (id) => onStarted(id),
  });

  return (
    <>
      <SectionHeader
        title="Start an attendance session"
        subtitle="The classroom layout comes from the admin's room plan. Students pick their own bench; each pair sharing a bench gets a random QR or passcode challenge."
      />
      {slot ? (
        <div className="mb-4 flex flex-wrap items-center gap-3 rounded-xl border border-cyan/40 bg-cyan/10 p-4 text-sm">
          <span className="rounded-full border border-cyan/40 px-2.5 py-1 text-[11px] uppercase tracking-wide text-cyan">
            {schedule.data?.current ? "Now on your timetable" : "Up next"}
          </span>
          <span>
            <span className="font-medium">{slot.subject}</span>
            <span className="text-muted-foreground"> · {slot.className}</span>
            <span className="block text-xs text-subtle">
              {slot.startTime}–{slot.endTime} · pre-selected below, change it if you like
            </span>
          </span>
          <Button
            variant="outline"
            size="sm"
            className="ml-auto"
            onClick={() => {
              setClassId(slot.classId);
              setSubject(slot.subject);
            }}
          >
            Use this lecture
          </Button>
        </div>
      ) : schedule.data && !schedule.data.today.length ? (
        <p className="mb-4 text-xs text-subtle">
          No timetable for today — pick the class and subject yourself.
        </p>
      ) : null}

      <Panel>
        <ErrorNote error={start.error} />
        <form
          className="grid gap-4 sm:grid-cols-2"
          onSubmit={(e) => {
            e.preventDefault();
            start.mutate();
          }}
        >
          <div className="space-y-2">
            <Label htmlFor="class">Class</Label>
            <select
              id="class"
              value={classId}
              onChange={(e) => setClassId(e.target.value)}
              className="h-10 w-full rounded-lg border border-input bg-surface px-3 text-sm text-foreground outline-none focus:border-primary"
            >
              {classes.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} ({c.studentCount})
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="subject">Subject</Label>
            <Input
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              placeholder="Data Structures"
              maxLength={80}
            />
          </div>
          <div className="sm:col-span-2">
            <Button type="submit" className="w-full" disabled={start.isPending || !classId}>
              {start.isPending ? "Starting…" : "Start session"}
            </Button>
          </div>
        </form>
      </Panel>
      {schedule.data?.today.length ? (
        <Panel>
          <h3 className="mb-3 text-base font-semibold">My lectures today</h3>
          <ul className="divide-y divide-border text-sm">
            {schedule.data.today.map((s2) => (
              <li key={s2.id} className="flex items-center justify-between gap-3 py-2">
                <span>
                  <span className="font-mono text-xs text-cyan">
                    {s2.startTime}–{s2.endTime}
                  </span>{" "}
                  <span className="font-medium">{s2.subject}</span>
                  <span className="block text-xs text-subtle">{s2.className}</span>
                </span>
                <span className="flex items-center gap-2">
                  {s2.current ? (
                    <span className="rounded-full border border-success/40 bg-success/10 px-2.5 py-1 text-[11px] text-success">
                      NOW
                    </span>
                  ) : null}
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setClassId(s2.classId);
                      setSubject(s2.subject);
                    }}
                  >
                    Select
                  </Button>
                </span>
              </li>
            ))}
          </ul>
        </Panel>
      ) : null}

      {classId ? <PreviousSessionCard classId={classId} /> : null}
    </>
  );
}

export function PreviousSessionCard({ classId }: { classId: string }) {
  const today = useQuery({
    queryKey: ["today-sessions", classId],
    queryFn: () => api.todaySessions(classId),
    refetchInterval: 30000,
  });
  const [openId, setOpenId] = useState<string | null>(null);

  const list = today.data ?? [];

  return (
    <Panel>
      <h3 className="text-base font-semibold">Earlier lectures today · this room</h3>
      <p className="mb-4 text-xs text-muted-foreground">
        Only sessions from today are shown — pick a lecture to see its bench details.
      </p>

      {!list.length ? (
        <p className="text-xs text-subtle">No finished lectures in this room today yet.</p>
      ) : (
        <div className="space-y-3">
          {list.map((p, i) => {
            const open = (openId ?? list[0]?.sessionId) === p.sessionId;
            const time = new Date(p.endedAt ?? p.startedAt).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            });
            return (
              <div key={p.sessionId} className="rounded-xl border border-border bg-elevated/60">
                <button
                  type="button"
                  onClick={() => setOpenId(open ? "" : p.sessionId)}
                  className="flex w-full items-center justify-between gap-3 px-3 py-2 text-left"
                >
                  <span className="text-sm font-semibold">
                    {i === 0 ? "Previous lecture · " : ""}
                    {p.subject}
                  </span>
                  <span className="text-[11px] text-muted-foreground">
                    {p.teacherName} · {time}
                  </span>
                </button>

                {open ? (
                  <div className="space-y-3 border-t border-border px-3 py-3">
                    <div className="grid gap-3 sm:grid-cols-3">
                      <div className="rounded-xl border border-cyan/40 bg-cyan/10 p-3">
                        <div className="mb-2 text-[11px] font-semibold tracking-wide text-cyan">
                          SINGLE-SEATED BENCHES
                        </div>
                        {p.singleBenches.length ? (
                          <ul className="space-y-1 text-[13px]">
                            {p.singleBenches.map((b) => (
                              <li key={b.benchNumber}>
                                <span className="font-medium">Bench {b.benchNumber}</span>
                                {b.students.length ? (
                                  <span className="text-muted-foreground">
                                    {" "}
                                    · {b.students.join(", ")}
                                  </span>
                                ) : null}
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-xs text-subtle">None</p>
                        )}
                      </div>
                      <div className="rounded-xl border border-border bg-elevated p-3">
                        <div className="mb-2 text-[11px] font-semibold tracking-wide text-muted-foreground">
                          EMPTY BENCHES
                        </div>
                        {p.emptyBenches.length ? (
                          <p className="text-[13px]">{p.emptyBenches.join(", ")}</p>
                        ) : (
                          <p className="text-xs text-subtle">None</p>
                        )}
                      </div>
                      <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-3">
                        <div className="mb-2 text-[11px] font-semibold tracking-wide text-destructive">
                          ABSENT STUDENTS
                        </div>
                        {p.absentees.length ? (
                          <ul className="space-y-1 text-[13px]">
                            {p.absentees.map((a) => (
                              <li key={a.rollNumber}>
                                {a.name}
                                <span className="text-muted-foreground"> · {a.rollNumber}</span>
                              </li>
                            ))}
                          </ul>
                        ) : (
                          <p className="text-xs text-subtle">Nobody absent</p>
                        )}
                      </div>
                    </div>

                    <div>
                      <div className="mb-2 text-[11px] font-semibold tracking-wide text-muted-foreground">
                        BENCH BY BENCH
                      </div>
                      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                        {p.benches.map((b) => (
                          <div
                            key={b.benchNumber}
                            className={`rounded-lg border p-2 text-[12px] ${statusTone(b.status)}`}
                          >
                            <div className="flex items-center justify-between">
                              <span className="font-semibold">Bench {b.benchNumber}</span>
                              <span className="text-[10px] uppercase text-muted-foreground">
                                {b.status}
                              </span>
                            </div>
                            {b.students.length ? (
                              <ul className="mt-1 space-y-0.5">
                                {b.students.map((s) => (
                                  <li key={s.rollNumber} className="truncate">
                                    {s.name}
                                    <span className="text-muted-foreground"> · {s.status}</span>
                                  </li>
                                ))}
                              </ul>
                            ) : (
                              <p className="mt-1 text-subtle">Nobody seated</p>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      )}
    </Panel>
  );
}


function LiveSession({ view, onLeave }: { view: SessionView; onLeave: () => void }) {
  const queryClient = useQueryClient();
  const [clock, setClock] = useState(view.remainingSeconds);
  const [lateRoll, setLateRoll] = useState("");

  useEffect(() => {
    setClock(view.remainingSeconds);
    if (!view.active) return;
    const id = setInterval(() => setClock((c) => Math.max(0, c - 1)), 1000);
    return () => clearInterval(id);
  }, [view.remainingSeconds, view.active]);

  const refresh = () => {
    void queryClient.invalidateQueries({ queryKey: ["session-view", view.sessionId] });
    void queryClient.invalidateQueries({ queryKey: ["teacher-home"] });
  };

  const act = useMutation({
    mutationFn: async (action: () => Promise<unknown>) => action(),
    onSuccess: refresh,
  });

  const report = useMutation({
    mutationFn: () => api.sessionReport(view.sessionId),
    onSuccess: (data) => {
      downloadCsv(
        `attendx-${data.className}-${data.subject}.csv`.replace(/\s+/g, "-").toLowerCase(),
        [
          ["Roll number", "Name", "Bench", "Status", "Partner verified", "Recorded at"],
          ...data.rows.map((r) => [
            r.rollNumber,
            r.name,
            r.benchNumber,
            r.status,
            r.verifiedByPartner ? "Yes" : "No",
            new Date(r.recordedAt).toLocaleString(),
          ]),
        ],
      );
    },
  });

  const progress = view.seatedCount ? (view.verifiedCount / view.seatedCount) * 100 : 0;

  return (
    <>
      <SectionHeader title={view.subject} subtitle={`${view.className} · ${view.teacherName}`} />
      <ErrorNote error={act.error ?? report.error} />

      <Panel>
        <div className="flex flex-wrap items-center gap-4">
          {view.active ? (
            <span className="animate-live-dot h-2.5 w-2.5 rounded-full bg-destructive" />
          ) : null}
          <div>
            <div className="font-display text-3xl font-extrabold">
              {view.active ? formatClock(clock) : "Ended"}
            </div>
            <div className="text-xs text-muted-foreground">
              {view.verifiedCount}/{view.seatedCount} students verified
            </div>
          </div>
          <div className="ml-auto flex flex-wrap gap-2">
            {view.active ? (
              <>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => act.mutate(() => api.extendTimer(view.sessionId, 2))}
                >
                  +2 min
                </Button>
                <Button size="sm" onClick={() => act.mutate(() => api.endSession(view.sessionId))}>
                  End &amp; save
                </Button>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={() =>
                    act.mutate(async () => {
                      await api.cancelSession(view.sessionId);
                      onLeave();
                    })
                  }
                >
                  Cancel
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" size="sm" onClick={() => report.mutate()}>
                  Export CSV
                </Button>
                <Button size="sm" onClick={onLeave}>
                  New session
                </Button>
              </>
            )}
          </div>
        </div>
        <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-surface">
          <div
            className="h-full bg-success transition-all duration-700"
            style={{ width: `${progress}%` }}
          />
        </div>
      </Panel>

      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat value={view.counts.present} label="Present" tone="green" />
        <Stat value={view.counts.late} label="Late" tone="amber" />
        <Stat value={view.counts.absent} label="Absent" tone="red" />
        <Stat value={view.totalBenches} label="Benches" tone="cyan" />
      </div>

      <PreviousSessionCard classId={view.classId} />



      {view.layout ? (
        <Panel>
          <h3 className="mb-3 text-base font-semibold">Room view</h3>
          <BenchLayoutGrid
            layout={view.layout}
            benches={view.benches.map((b) => ({
              benchNumber: b.benchNumber,
              status: b.status,
              seats: b.students.map((st) => ({
                seat: st.seat,
                name: st.name,
                verified: st.verified,
              })),
            }))}
          />
        </Panel>
      ) : null}

      <Panel>
        <h3 className="mb-3 text-base font-semibold">Benches</h3>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {view.benches.map((bench) => (
            <div
              key={bench.benchNumber}
              className={`rounded-xl border p-4 ${statusTone(bench.status)}`}
            >
              <div className="mb-2 flex items-center justify-between text-[11px] font-semibold tracking-wide text-muted-foreground">
                <span>BENCH {bench.benchNumber}</span>
                <span>{bench.status}</span>
              </div>
              {bench.students.length ? (
                bench.students.map((s) => (
                  <div key={s.rollNumber} className="flex items-center gap-2 py-1 text-[13px]">
                    <span
                      className={`h-1.5 w-1.5 shrink-0 rounded-full ${
                        s.verified ? "bg-success" : s.entered ? "bg-warning" : "bg-subtle"
                      }`}
                    />
                    <span className="flex-1 truncate">{s.name}</span>
                    <span className="text-[10px] text-subtle">{s.method}</span>
                  </div>
                ))
              ) : (
                <p className="text-xs text-subtle">Nobody seated here</p>
              )}
              {view.active ? (
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {bench.students.length ? (
                    <Button
                      variant="outline"
                      size="sm"
                      className="h-7 px-2 text-[11px]"
                      onClick={() =>
                        act.mutate(() => api.setBenchStatus(view.sessionId, bench.benchNumber, "PRESENT"))
                      }
                    >
                      {bench.students.length === 1 ? "Approve single student" : "Approve both"}
                    </Button>
                  ) : null}
                  <Button
                    variant="outline"
                    size="sm"
                    className="h-7 px-2 text-[11px]"
                    onClick={() =>
                      act.mutate(() => api.setBenchStatus(view.sessionId, bench.benchNumber, "EMPTY"))
                    }
                  >
                    Mark seat empty
                  </Button>
                </div>
              ) : null}
            </div>
          ))}
        </div>
      </Panel>

      {view.active ? (
        <Panel>
          <h3 className="mb-1 text-base font-semibold">Late entry</h3>
          <p className="mb-3 text-sm text-muted-foreground">
            Record a student who arrived after their bench was closed.
          </p>
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              if (lateRoll.trim()) {
                act.mutate(() => api.markLate(view.sessionId, lateRoll.trim()));
                setLateRoll("");
              }
            }}
          >
            <Input
              value={lateRoll}
              onChange={(e) => setLateRoll(e.target.value.toUpperCase())}
              placeholder="Roll number"
              maxLength={40}
            />
            <Button type="submit" variant="outline">
              Mark late
            </Button>
          </form>
        </Panel>
      ) : (
        <SessionReportCard sessionId={view.sessionId} />
      )}
    </>
  );
}

function SessionReportCard({ sessionId }: { sessionId: string }) {
  const report = useQuery({
    queryKey: ["session-report", sessionId],
    queryFn: () => api.sessionReport(sessionId),
  });

  return (
    <Panel>
      <h3 className="mb-3 text-base font-semibold">Attendance record</h3>
      {report.data?.rows.length ? (
        <ul className="divide-y divide-border text-sm">
          {report.data.rows.map((r) => (
            <li key={r.rollNumber} className="flex items-center justify-between py-2.5">
              <span>
                <span className="font-medium">{r.name}</span>
                <span className="text-muted-foreground"> · {r.rollNumber} · bench {r.benchNumber}</span>
              </span>
              <StatusPill status={r.status} />
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-sm text-muted-foreground">No records for this session.</p>
      )}
    </Panel>
  );
}
