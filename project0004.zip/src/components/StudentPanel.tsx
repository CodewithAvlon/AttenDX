import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { QRCodeSVG } from "qrcode.react";
import { useEffect, useState } from "react";

import { BenchLayoutGrid } from "@/components/BenchLayoutGrid";
import { ErrorNote, Panel, SectionHeader, Shell, Stat } from "@/components/Shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  api,
  formatClock,
  type ActiveStudentSession,
  type Me,
  type StudentSession,
} from "@/lib/attendx";

export function StudentPanel({ me }: { me: Me }) {
  const queryClient = useQueryClient();
  const [code, setCode] = useState("");
  const [feedback, setFeedback] = useState<string | null>(null);

  const session = useQuery({
    queryKey: ["student-session"],
    queryFn: api.studentSession,
    refetchInterval: 4000,
    refetchOnWindowFocus: true,
  });

  const history = useQuery({ queryKey: ["my-history"], queryFn: api.myHistory });

  const data = session.data;
  const live: ActiveStudentSession | null = data && data.active ? data : null;
  const [clock, setClock] = useState(0);

  useEffect(() => {
    if (!live) return;
    setClock(live.remainingSeconds);
    const id = setInterval(() => setClock((c) => Math.max(0, c - 1)), 1000);
    return () => clearInterval(id);
  }, [live?.sessionId, live?.remainingSeconds, live]);

  const checkIn = useMutation({
    mutationFn: (bench: number) => api.checkIn(bench),
    onSuccess: (next) => queryClient.setQueryData(["student-session"], next),
  });

  const verify = useMutation({
    mutationFn: (value: string) => api.verify(value),
    onSuccess: (next: StudentSession) => {
      queryClient.setQueryData(["student-session"], next);
      setCode("");
      if (next.active && next.lastResult === "INCORRECT") {
        setFeedback(`Incorrect code. ${next.attemptsLeft ?? 0} attempt(s) left.`);
      } else {
        setFeedback(null);
        void queryClient.invalidateQueries({ queryKey: ["my-history"] });
      }
    },
  });

  const total = history.data?.length ?? 0;
  const present = history.data?.filter((h) => h.status !== "ABSENT").length ?? 0;

  return (
    <Shell
      title="Student"
      name={`${me.name} · ${me.rollNumber ?? ""}`}
      badge={
        live ? (
          <span className="flex items-center gap-2 rounded-full border border-success/40 bg-success/10 px-3 py-1.5 text-xs text-success">
            <span className="animate-live-dot h-2 w-2 rounded-full bg-destructive" />
            Live · {formatClock(clock)}
          </span>
        ) : null
      }
    >
      <SectionHeader
        title={live ? `${live.subject}` : "No live session"}
        subtitle={
          live
            ? `${live.className} · ${live.teacherName}`
            : `${me.className ?? "Your class"} · waiting for a session`
        }
      />

      <ErrorNote error={session.error ?? checkIn.error ?? verify.error} />

      {!live ? (
        <Panel className="text-center">
          <div className="animate-pulse-ring mx-auto mb-4 h-3.5 w-3.5 rounded-full bg-primary" />
          <p className="text-sm text-muted-foreground">
            Waiting for your teacher to start an attendance session.
          </p>
        </Panel>
      ) : !live.seated ? (
        <Panel>
          <h3 className="text-base font-semibold">Choose your bench</h3>
          <p className="mb-4 text-sm text-muted-foreground">
            Tap any bench with a free seat. Whoever shares your bench becomes your verification
            partner.
          </p>
          <BenchLayoutGrid
            layout={live.layout}
            benches={live.benches}
            onSelect={(bench) => checkIn.mutate(bench)}
            disabled={checkIn.isPending}
          />
        </Panel>
      ) : live.verified ? (
        <div className="grid gap-4 md:grid-cols-2">
          <Panel className="text-center">
            <div className="font-display text-2xl font-extrabold text-success">
              {live.status === "LATE" ? "Marked late" : live.status === "PRESENT" ? "Marked present" : "You are verified"}
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              Bench {live.myBench} seat {live.mySeat} ·{" "}
              {live.partnerVerified ? "both seats confirmed" : "waiting for your partner to confirm"}
            </p>
            {live.status ? (
              <p className="mt-3 text-xs text-subtle">
                Attendance recorded as {live.status}.
              </p>
            ) : (
              <p className="mt-3 text-xs text-subtle">
                Attendance is recorded once your partner verifies you too.
              </p>
            )}
          </Panel>

          {live.partnerVerified ? null : (
            <Panel className="text-center">
              <p className="text-xs uppercase tracking-wide text-muted-foreground">
                Keep showing this to {live.partnerName ?? "your bench partner"}
              </p>
              {live.method === "QR" ? (
                <div className="mx-auto mt-4 w-fit rounded-xl bg-foreground p-3">
                  <QRCodeSVG value={live.myCode ?? ""} size={148} />
                </div>
              ) : null}
              <div className="font-display mt-4 text-3xl font-extrabold tracking-[0.5em] text-cyan">
                {live.myCode}
              </div>
              <p className="mt-3 text-xs text-subtle">
                Verification method: {live.method === "QR" ? "QR code" : "Passcode"}
              </p>
            </Panel>
          )}
        </div>
      ) : !live.partnerName ? (
        <Panel>
          <h3 className="text-base font-semibold">Seated at bench {live.myBench}</h3>
          <p className="mb-4 text-sm text-muted-foreground">
            You are seat {live.mySeat}. Waiting for someone to take the other seat — you can also
            move to another bench.
          </p>
          <BenchLayoutGrid
            layout={live.layout}
            benches={live.benches}
            highlight={live.myBench}
            onSelect={(bench) => checkIn.mutate(bench)}
            disabled={checkIn.isPending}
          />
        </Panel>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          <Panel className="text-center">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">
              Show this to your bench partner
            </p>
            {live.method === "QR" ? (
              <div className="mx-auto mt-4 w-fit rounded-xl bg-foreground p-3">
                <QRCodeSVG value={live.myCode ?? ""} size={148} />
              </div>
            ) : null}
            <div className="font-display mt-4 text-3xl font-extrabold tracking-[0.5em] text-cyan">
              {live.myCode}
            </div>
            <p className="mt-3 text-xs text-subtle">
              Verification method: {live.method === "QR" ? "QR code" : "Passcode"}
            </p>
          </Panel>

          <Panel>
            <h3 className="text-base font-semibold">Verify your partner</h3>
            <p className="mb-4 text-sm text-muted-foreground">
              Enter the code shown on {live.partnerName}'s screen.
            </p>
            <form
              className="flex gap-2"
              onSubmit={(e) => {
                e.preventDefault();
                if (code.trim()) verify.mutate(code.trim());
              }}
            >
              <Input
                value={code}
                onChange={(e) => setCode(e.target.value.toUpperCase())}
                maxLength={8}
                placeholder="ABCD"
                className="font-display tracking-[0.4em]"
                disabled={live.locked}
              />
              <Button type="submit" disabled={verify.isPending || live.locked}>
                Verify
              </Button>
            </form>
            {live.locked ? (
              <p className="mt-3 text-sm text-destructive">
                Too many incorrect attempts. Ask your teacher to verify you manually.
              </p>
            ) : (
              <p className="mt-3 text-xs text-muted-foreground">
                {live.attemptsLeft} of 5 attempts remaining. Timer: {formatClock(clock)}
              </p>
            )}
            {feedback ? <p className="mt-2 text-sm text-warning">{feedback}</p> : null}
          </Panel>
        </div>
      )}

      <div className="mb-4 mt-8 grid grid-cols-3 gap-3">
        <Stat value={total} label="Sessions recorded" />
        <Stat value={present} label="Present / late" tone="green" />
        <Stat
          value={`${total ? Math.round((present / total) * 100) : 0}%`}
          label="Attendance rate"
          tone="cyan"
        />
      </div>

      <Panel>
        <h3 className="mb-3 text-base font-semibold">My attendance history</h3>
        {history.data && history.data.length > 0 ? (
          <ul className="divide-y divide-border text-sm">
            {history.data.map((h, i) => (
              <li key={i} className="flex items-center justify-between py-2.5">
                <span>
                  <span className="font-medium">{h.subject}</span>{" "}
                  <span className="text-muted-foreground">· {h.className}</span>
                </span>
                <span className="flex items-center gap-3">
                  <span className="text-xs text-subtle">
                    {new Date(h.date).toLocaleDateString()}
                  </span>
                  <StatusPill status={h.status} />
                </span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted-foreground">No attendance recorded yet.</p>
        )}
      </Panel>
    </Shell>
  );
}

export function StatusPill({ status }: { status: string }) {
  const tone =
    status === "PRESENT"
      ? "border-success/40 bg-success/10 text-success"
      : status === "LATE"
        ? "border-warning/40 bg-warning/10 text-warning"
        : "border-destructive/40 bg-destructive/10 text-destructive";
  return (
    <span className={`rounded-full border px-2.5 py-1 text-[11px] font-semibold ${tone}`}>
      {status}
    </span>
  );
}
