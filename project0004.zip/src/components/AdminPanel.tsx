import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";

import { ActivityFeed } from "@/components/ActivityFeed";
import { TimetableManager } from "@/components/TimetableManager";
import { ErrorNote, Panel, SectionHeader, Shell, Stat } from "@/components/Shell";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { api, type AdminHome, type LayoutCell, type Me } from "@/lib/attendx";

export function AdminPanel({ me }: { me: Me }) {
  const queryClient = useQueryClient();
  const home = useQuery({ queryKey: ["admin-home"], queryFn: api.adminHome });
  const [search, setSearch] = useState("");

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["admin-home"] });
  const data = home.data;

  const students = (data?.students ?? []).filter((s) =>
    `${s.rollNumber} ${s.name} ${s.classId}`.toLowerCase().includes(search.toLowerCase()),
  );

  return (
    <Shell title="Administrator" name={me.name}>
      <SectionHeader
        title="Institution setup"
        subtitle="Manage the roster, seating layouts and staff access."
      />
      <ErrorNote error={home.error} />

      <div className="mb-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <Stat value={data?.classes.length ?? 0} label="Classes" />
        <Stat value={data?.students.length ?? 0} label="Students" tone="cyan" />
        <Stat value={data?.staff.length ?? 0} label="Staff accounts" tone="green" />
        <Stat
          value={data?.sessions.filter((s) => s.active).length ?? 0}
          label="Live sessions"
          tone="amber"
        />
      </div>

      {data ? <LayoutEditor classes={data.classes} onSaved={refresh} /> : null}

      {data ? <TimetableManager classes={data.classes} staff={data.staff} /> : null}

      <Panel>
        <div className="mb-3 flex flex-wrap items-center gap-3">
          <h3 className="text-base font-semibold">Student roster</h3>
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search roll number, name or class"
            className="ml-auto w-full sm:w-72"
          />
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="text-xs uppercase tracking-wide text-subtle">
              <tr>
                <th className="py-2 pr-3">Roll</th>
                <th className="py-2 pr-3">Name</th>
                <th className="py-2 pr-3">Class</th>
                <th className="py-2 pr-3">Attendance</th>
                <th className="py-2 pr-3">Access</th>
                <th />
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {students.map((s) => (
                <tr key={s.rollNumber}>
                  <td className="py-2.5 pr-3 font-medium">{s.rollNumber}</td>
                  <td className="py-2.5 pr-3">{s.name}</td>
                  <td className="py-2.5 pr-3 text-muted-foreground">{s.classId}</td>
                  <td className="py-2.5 pr-3">
                    {s.sessionsCounted
                      ? `${Math.round((s.presentCount / s.sessionsCounted) * 100)}%`
                      : "—"}
                  </td>
                  <td className="py-2.5 pr-3 text-xs">
                    {s.registered ? (
                      <span className="text-success">registered</span>
                    ) : (
                      <span className="text-subtle">pending</span>
                    )}
                  </td>
                  <td className="py-2.5">
                    <RemoveButton
                      onConfirm={async () => {
                        await api.deleteStudent(s.rollNumber);
                        await refresh();
                      }}
                    />
                  </td>
                </tr>
              ))}
              {students.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-4 text-sm text-muted-foreground">
                    No students match this search.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </Panel>

      {data ? <StudentForm classes={data.classes} onSaved={refresh} /> : null}
      {data ? <StaffSection staff={data.staff} onSaved={refresh} /> : null}

      <SectionHeader
        title="System activity log"
        subtitle="Everything happening across classes — sessions, seat choices, verifications and teacher overrides."
      />
      <Panel>
        <ActivityFeed
          entries={data?.activity ?? []}
          dotClass="bg-cyan"
          className="max-h-96 overflow-y-auto pr-1"
        />
      </Panel>

    </Shell>
  );
}

function RemoveButton({ onConfirm }: { onConfirm: () => Promise<void> }) {
  const [busy, setBusy] = useState(false);
  return (
    <Button
      variant="ghost"
      size="sm"
      disabled={busy}
      className="text-destructive hover:text-destructive"
      onClick={async () => {
        setBusy(true);
        try {
          await onConfirm();
        } finally {
          setBusy(false);
        }
      }}
    >
      Remove
    </Button>
  );
}

function StudentForm({
  classes,
  onSaved,
}: {
  classes: AdminHome["classes"];
  onSaved: () => void;
}) {
  const [form, setForm] = useState({
    roll: "",
    name: "",
    classId: "",
  });

  useEffect(() => {
    if (!form.classId && classes.length) setForm((f) => ({ ...f, classId: classes[0]!.id }));
  }, [classes, form.classId]);

  const save = useMutation({
    mutationFn: () => api.upsertStudent(form),
    onSuccess: () => {
      setForm((f) => ({ ...f, roll: "", name: "" }));
      onSaved();
    },
  });

  return (
    <Panel>
      <h3 className="mb-1 text-base font-semibold">Add or update a student</h3>
      <p className="mb-4 text-sm text-muted-foreground">
        Students choose their own bench during a session; whoever shares a bench becomes each other's verification partner.
      </p>
      <ErrorNote error={save.error} />
      <form
        className="grid gap-3 sm:grid-cols-3"
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
      >
        <div className="space-y-2">
          <Label htmlFor="roll">Roll number</Label>
          <Input
            id="roll"
            value={form.roll}
            onChange={(e) => setForm({ ...form, roll: e.target.value.toUpperCase() })}
            maxLength={40}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="sname">Name</Label>
          <Input
            id="sname"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            maxLength={80}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="sclass">Class</Label>
          <select
            id="sclass"
            value={form.classId}
            onChange={(e) => setForm({ ...form, classId: e.target.value })}
            className="h-10 w-full rounded-lg border border-input bg-surface px-3 text-sm text-foreground outline-none focus:border-primary"
          >
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
        <div className="sm:col-span-3">
          <Button type="submit" disabled={save.isPending}>
            {save.isPending ? "Saving…" : "Save student"}
          </Button>
        </div>
      </form>
    </Panel>
  );
}

function StaffSection({ staff, onSaved }: { staff: AdminHome["staff"]; onSaved: () => void }) {
  const [form, setForm] = useState({ loginId: "", name: "", role: "teacher" });
  const save = useMutation({
    mutationFn: () => api.upsertStaff(form.loginId, form.name, form.role),
    onSuccess: () => {
      setForm({ loginId: "", name: "", role: "teacher" });
      onSaved();
    },
  });

  return (
    <Panel>
      <h3 className="mb-3 text-base font-semibold">Staff access</h3>
      <ErrorNote error={save.error} />
      <ul className="mb-5 divide-y divide-border text-sm">
        {staff.map((s) => (
          <li key={s.loginId} className="flex items-center justify-between py-2.5">
            <span>
              <span className="font-medium">{s.loginId}</span>
              <span className="text-muted-foreground"> · {s.name} · {s.role}</span>
            </span>
            <span className="flex items-center gap-3">
              <span className="text-xs">
                {s.registered ? (
                  <span className="text-success">registered</span>
                ) : (
                  <span className="text-subtle">pending</span>
                )}
              </span>
              <RemoveButton
                onConfirm={async () => {
                  await api.deleteStaff(s.loginId);
                  onSaved();
                }}
              />
            </span>
          </li>
        ))}
      </ul>
      <form
        className="grid gap-3 sm:grid-cols-3"
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate();
        }}
      >
        <div className="space-y-2">
          <Label htmlFor="stid">Staff ID</Label>
          <Input
            id="stid"
            value={form.loginId}
            onChange={(e) => setForm({ ...form, loginId: e.target.value })}
            maxLength={40}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="stname">Name</Label>
          <Input
            id="stname"
            value={form.name}
            onChange={(e) => setForm({ ...form, name: e.target.value })}
            maxLength={80}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="strole">Role</Label>
          <select
            id="strole"
            value={form.role}
            onChange={(e) => setForm({ ...form, role: e.target.value })}
            className="h-10 w-full rounded-lg border border-input bg-surface px-3 text-sm text-foreground outline-none focus:border-primary"
          >
            <option value="teacher">Teacher</option>
            <option value="admin">Administrator</option>
            <option value="principal">Principal</option>
          </select>
        </div>
        <div className="sm:col-span-3">
          <Button type="submit" disabled={save.isPending}>
            {save.isPending ? "Saving…" : "Save staff account"}
          </Button>
        </div>
      </form>
    </Panel>
  );
}

function LayoutEditor({
  classes,
  onSaved,
}: {
  classes: AdminHome["classes"];
  onSaved: () => void;
}) {
  const [classId, setClassId] = useState(classes[0]?.id ?? "");
  const selected = classes.find((c) => c.id === classId);
  const [rows, setRows] = useState(selected?.layout?.rows ?? 3);
  const [cols, setCols] = useState(selected?.layout?.cols ?? 4);
  const [cells, setCells] = useState<LayoutCell[]>(selected?.layout?.cells ?? []);

  useEffect(() => {
    const next = classes.find((c) => c.id === classId);
    setRows(next?.layout?.rows ?? 3);
    setCols(next?.layout?.cols ?? 4);
    setCells(next?.layout?.cells ?? []);
  }, [classId, classes]);

  const save = useMutation({
    mutationFn: () => api.saveLayout(classId, rows, cols, cells),
    onSuccess: onSaved,
  });

  function toggle(row: number, col: number) {
    const existing = cells.find((c) => c.row === row && c.col === col);
    if (existing) {
      const remaining = cells
        .filter((c) => !(c.row === row && c.col === col))
        .sort((a, b) => a.row - b.row || a.col - b.col)
        .map((c, i) => ({ ...c, benchNumber: i + 1 }));
      setCells(remaining);
      return;
    }
    const next = [...cells, { row, col, benchNumber: 0 }]
      .sort((a, b) => a.row - b.row || a.col - b.col)
      .map((c, i) => ({ ...c, benchNumber: i + 1 }));
    setCells(next);
  }

  const map = new Map(cells.map((c) => [`${c.row}:${c.col}`, c.benchNumber]));

  return (
    <Panel>
      <h3 className="mb-1 text-base font-semibold">Room layout</h3>
      <p className="mb-4 text-sm text-muted-foreground">
        Click a cell to place or remove a bench. Bench numbers renumber automatically, left to right.
      </p>
      <ErrorNote error={save.error} />
      <div className="mb-4 grid gap-3 sm:grid-cols-3">
        <div className="space-y-2">
          <Label htmlFor="lclass">Class</Label>
          <select
            id="lclass"
            value={classId}
            onChange={(e) => setClassId(e.target.value)}
            className="h-10 w-full rounded-lg border border-input bg-surface px-3 text-sm text-foreground outline-none focus:border-primary"
          >
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="lrows">Rows</Label>
          <Input
            id="lrows"
            type="number"
            min={1}
            max={12}
            value={rows}
            onChange={(e) => setRows(Math.min(12, Math.max(1, Number(e.target.value))))}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="lcols">Columns</Label>
          <Input
            id="lcols"
            type="number"
            min={1}
            max={12}
            value={cols}
            onChange={(e) => setCols(Math.min(12, Math.max(1, Number(e.target.value))))}
          />
        </div>
      </div>

      <div className="rounded-2xl border border-border bg-surface/60 px-3 py-5">
        <div className="mb-6 flex flex-col items-center">
          <div className="flex h-12 w-[min(520px,92%)] items-center justify-center rounded-md border-4 border-[color-mix(in_oklab,var(--warning)_45%,var(--border))] bg-[color-mix(in_oklab,var(--success)_14%,var(--background))] text-[11px] font-bold uppercase tracking-[0.35em] text-subtle shadow-panel">
            Black board
          </div>
          <span className="mt-2 text-[10px] font-semibold uppercase tracking-[0.3em] text-subtle">
            Front of class
          </span>
        </div>

        <div className="overflow-x-auto pb-2">
          <div className="flex min-w-full justify-center">
            <div
              className="grid justify-center gap-2.5"
              style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}
            >
            {Array.from({ length: rows * cols }, (_, i) => {
              const row = Math.floor(i / cols);
              const col = i % cols;
              const bench = map.get(`${row}:${col}`);
              return (
                <button
                  key={i}
                  type="button"
                  onClick={() => toggle(row, col)}
                  aria-label={bench ? `Remove bench ${bench}` : `Place a bench at row ${row + 1}, column ${col + 1}`}
                  className={`group flex h-[68px] w-[84px] flex-col items-center justify-center gap-1 rounded-xl border transition-all ${
                    bench
                      ? "border-primary/70 bg-elevated hover:-translate-y-0.5"
                      : "border-dashed border-border text-subtle hover:border-primary hover:text-cyan"
                  }`}
                >
                  {bench ? (
                    <>
                      <span className="flex items-end gap-1">
                        {(["A", "B"] as const).map((s) => (
                          <span key={s} className="flex flex-col items-center">
                            <span className="h-4 w-6 rounded-t-md border border-b-0 border-border bg-background/60" />
                            <span className="h-1 w-7 rounded-b-md border border-t-0 border-border bg-background/60" />
                          </span>
                        ))}
                      </span>
                      <span className="h-1.5 w-[54px] rounded-full bg-[color-mix(in_oklab,var(--warning)_35%,var(--border))]" />
                      <span className="text-[10px] font-bold uppercase tracking-wider text-muted-foreground">
                        {bench}
                      </span>
                    </>
                  ) : (
                    <span className="text-lg font-bold leading-none">+</span>
                  )}
                </button>
              );
            })}
          </div>
          </div>
        </div>
      </div>


      <Button className="mt-4" onClick={() => save.mutate()} disabled={save.isPending || !classId}>
        {save.isPending ? "Saving…" : "Save layout"}
      </Button>
    </Panel>
  );
}
