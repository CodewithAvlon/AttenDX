import { useQuery } from "@tanstack/react-query";

import { ActivityFeed } from "@/components/ActivityFeed";
import { ErrorNote, Panel, SectionHeader, Shell, Stat } from "@/components/Shell";

import { api, type Me } from "@/lib/attendx";

export function PrincipalPanel({ me }: { me: Me }) {
  const home = useQuery({
    queryKey: ["principal-home"],
    queryFn: api.principalHome,
    refetchInterval: 10000,
  });
  const data = home.data;

  return (
    <Shell title="Principal" name={me.name}>
      <SectionHeader
        title="Institution overview"
        subtitle="Live attendance activity across every classroom."
      />
      <ErrorNote error={home.error} />

      <div className="mb-5 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <Stat value={data?.totals.classes ?? 0} label="Classes" />
        <Stat value={data?.totals.students ?? 0} label="Students" tone="cyan" />
        <Stat value={data?.totals.staff ?? 0} label="Staff" />
        <Stat value={data?.totals.liveSessions ?? 0} label="Live now" tone="amber" />
        <Stat value={data?.totals.sessionsToday ?? 0} label="Sessions today" />
        <Stat
          value={`${data?.totals.attendanceRate ?? 0}%`}
          label="30-day attendance"
          tone="green"
        />
      </div>

      <Panel>
        <h3 className="mb-3 text-base font-semibold">Live sessions</h3>
        {data?.liveSessions.length ? (
          <ul className="divide-y divide-border text-sm">
            {data.liveSessions.map((s) => (
              <li key={s.id} className="flex items-center justify-between gap-3 py-2.5">
                <span>
                  <span className="font-medium">{s.subject}</span>
                  <span className="text-muted-foreground"> · {s.className}</span>
                  <span className="block text-xs text-subtle">
                    {s.teacherName} · started {new Date(s.startedAt).toLocaleTimeString()}
                  </span>
                </span>
                <span className="flex items-center gap-2 text-xs text-success">
                  <span className="animate-live-dot h-2 w-2 rounded-full bg-destructive" />
                  {s.verified}/{s.seated} verified
                </span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted-foreground">No sessions are running right now.</p>
        )}
      </Panel>

      <Panel>
        <h3 className="mb-3 text-base font-semibold">Recent sessions</h3>
        {data?.recentSessions.length ? (
          <ul className="divide-y divide-border text-sm">
            {data.recentSessions.map((s) => (
              <li key={s.id} className="flex items-center justify-between gap-3 py-2.5">
                <span>
                  <span className="font-medium">{s.subject}</span>
                  <span className="text-muted-foreground"> · {s.className}</span>
                  <span className="block text-xs text-subtle">
                    {s.teacherName} · {new Date(s.startedAt).toLocaleString()}
                  </span>
                </span>
                <span className="text-xs text-muted-foreground">
                  {s.total ? `${Math.round((s.present / s.total) * 100)}%` : "—"} present
                </span>
              </li>
            ))}
          </ul>
        ) : (
          <p className="text-sm text-muted-foreground">No sessions recorded yet.</p>
        )}
      </Panel>

      <Panel>
        <h3 className="mb-3 text-base font-semibold">Activity</h3>
        <ActivityFeed entries={data?.activity ?? []} />
      </Panel>

    </Shell>
  );
}
