import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";

import { ErrorNote, Panel } from "@/components/Shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { DAY_NAMES, api, type AdminHome, type TimetableInput } from "@/lib/attendx";

const selectClass =
  "h-10 w-full rounded-lg border border-input bg-surface px-3 text-sm text-foreground outline-none focus:border-primary";

export function TimetableManager({
  classes,
  staff,
}: {
  classes: AdminHome["classes"];
  staff: AdminHome["staff"];
}) {
  const queryClient = useQueryClient();
  const teachers = staff.filter((s) => s.role === "teacher");
  const list = useQuery({ queryKey: ["timetable"], queryFn: api.timetable });

  const [teacherLogin, setTeacherLogin] = useState("");
  const [classId, setClassId] = useState("");
  const [subject, setSubject] = useState("");
  const [dayOfWeek, setDayOfWeek] = useState(1);
  const [startTime, setStartTime] = useState("09:00");
  const [endTime, setEndTime] = useState("10:00");
  const [bulk, setBulk] = useState("");
  const [replace, setReplace] = useState(false);
  const [bulkError, setBulkError] = useState<string | null>(null);

  useEffect(() => {
    if (!teacherLogin && teachers.length) setTeacherLogin(teachers[0]!.loginId);
    if (!classId && classes.length) setClassId(classes[0]!.id);
  }, [teachers, teacherLogin, classes, classId]);

  const refresh = () => queryClient.invalidateQueries({ queryKey: ["timetable"] });

  const save = useMutation({
    mutationFn: (entries: TimetableInput[]) => api.saveTimetable(entries, false),
    onSuccess: () => {
      setSubject("");
      void refresh();
    },
  });

  const upload = useMutation({
    mutationFn: (entries: TimetableInput[]) => api.saveTimetable(entries, replace),
    onSuccess: () => {
      setBulk("");
      void refresh();
    },
  });

  const remove = useMutation({
    mutationFn: (id: string) => api.deleteTimetableEntry(id),
    onSuccess: () => void refresh(),
  });

  function parseBulk(): TimetableInput[] {
    const rows = bulk
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean)
      .filter((line) => !/^teacher/i.test(line));
    if (!rows.length) throw new Error("Paste at least one row.");
    return rows.map((line, index) => {
      const parts = line.split(/[,;\t]/).map((p) => p.trim());
      if (parts.length < 6) throw new Error(`Row ${index + 1}: expected 6 values.`);
      const [teacher, cls, subj, day, start, end] = parts as [string, string, string, string, string, string];
      const dayIndex = DAY_NAMES.findIndex((d) => d.toLowerCase().startsWith(day.slice(0, 3).toLowerCase()));
      const resolved = /^\d$/.test(day) ? Number(day) : dayIndex;
      if (resolved < 0 || resolved > 6) throw new Error(`Row ${index + 1}: unknown day "${day}".`);
      return {
        teacherLogin: teacher,
        classId: cls,
        subject: subj,
        dayOfWeek: resolved,
        startTime: start,
        endTime: end,
      };
    });
  }

  const grouped = DAY_NAMES.map((name, day) => ({
    name,
    day,
    rows: (list.data ?? []).filter((r) => r.dayOfWeek === day),
  })).filter((g) => g.rows.length);

  return (
    <Panel>
      <h3 className="mb-1 text-base font-semibold">Teacher timetable</h3>
      <p className="mb-4 text-sm text-muted-foreground">
        Upload the weekly schedule. Teachers see their current lecture pre-selected when they start a
        session — they can still change it.
      </p>
      <ErrorNote error={list.error ?? save.error ?? upload.error ?? remove.error} />

      <form
        className="grid gap-3 sm:grid-cols-3"
        onSubmit={(e) => {
          e.preventDefault();
          save.mutate([{ teacherLogin, classId, subject, dayOfWeek, startTime, endTime }]);
        }}
      >
        <div className="space-y-2">
          <Label htmlFor="tt-teacher">Teacher</Label>
          <select
            id="tt-teacher"
            value={teacherLogin}
            onChange={(e) => setTeacherLogin(e.target.value)}
            className={selectClass}
          >
            {teachers.map((t) => (
              <option key={t.loginId} value={t.loginId}>
                {t.name} ({t.loginId})
              </option>
            ))}
          </select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="tt-class">Class</Label>
          <select
            id="tt-class"
            value={classId}
            onChange={(e) => setClassId(e.target.value)}
            className={selectClass}
          >
            {classes.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="tt-subject">Subject</Label>
          <Input
            id="tt-subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="Data Structures"
            maxLength={80}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="tt-day">Day</Label>
          <select
            id="tt-day"
            value={dayOfWeek}
            onChange={(e) => setDayOfWeek(Number(e.target.value))}
            className={selectClass}
          >
            {DAY_NAMES.map((d, i) => (
              <option key={d} value={i}>
                {d}
              </option>
            ))}
          </select>
        </div>
        <div className="space-y-2">
          <Label htmlFor="tt-start">Starts</Label>
          <Input id="tt-start" type="time" value={startTime} onChange={(e) => setStartTime(e.target.value)} />
        </div>
        <div className="space-y-2">
          <Label htmlFor="tt-end">Ends</Label>
          <Input id="tt-end" type="time" value={endTime} onChange={(e) => setEndTime(e.target.value)} />
        </div>
        <div className="sm:col-span-3">
          <Button type="submit" disabled={save.isPending || !subject.trim() || !teacherLogin}>
            {save.isPending ? "Saving…" : "Add to timetable"}
          </Button>
        </div>
      </form>

      <div className="mt-6 space-y-2 border-t border-border pt-5">
        <Label htmlFor="tt-bulk">Bulk upload</Label>
        <p className="text-xs text-subtle">
          One lecture per line: <span className="text-muted-foreground">teacherId, classId, subject, day, start, end</span>
          {" — e.g. "}
          <span className="text-muted-foreground">TCH001, cse-s3-a, Data Structures, Monday, 09:00, 10:00</span>
        </p>
        <textarea
          id="tt-bulk"
          value={bulk}
          onChange={(e) => setBulk(e.target.value)}
          rows={5}
          placeholder={"TCH001, cse-s3-a, Data Structures, Monday, 09:00, 10:00"}
          className="w-full rounded-lg border border-input bg-surface p-3 font-mono text-xs text-foreground outline-none focus:border-primary"
        />
        <div className="flex flex-wrap items-center gap-3">
          <label className="flex items-center gap-2 text-xs text-muted-foreground">
            <input
              type="checkbox"
              checked={replace}
              onChange={(e) => setReplace(e.target.checked)}
              className="h-4 w-4 accent-primary"
            />
            Replace the whole timetable
          </label>
          <Button
            variant="outline"
            disabled={upload.isPending || !bulk.trim()}
            onClick={() => {
              setBulkError(null);
              try {
                upload.mutate(parseBulk());
              } catch (err) {
                setBulkError(err instanceof Error ? err.message : "Could not read that list.");
              }
            }}
          >
            {upload.isPending ? "Uploading…" : "Upload schedule"}
          </Button>
          {bulkError ? <span className="text-xs text-destructive">{bulkError}</span> : null}
        </div>
      </div>

      <div className="mt-6 border-t border-border pt-5">
        {grouped.length ? (
          <div className="space-y-4">
            {grouped.map((g) => (
              <div key={g.day}>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-subtle">{g.name}</p>
                <ul className="divide-y divide-border text-sm">
                  {g.rows.map((r) => (
                    <li key={r.id} className="flex items-center justify-between gap-3 py-2">
                      <span>
                        <span className="font-mono text-xs text-cyan">
                          {r.startTime}–{r.endTime}
                        </span>{" "}
                        <span className="font-medium">{r.subject}</span>
                        <span className="block text-xs text-subtle">
                          {r.className} · {r.teacherName ?? r.teacherLogin}
                        </span>
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => remove.mutate(r.id)}
                        className="text-destructive"
                      >
                        Remove
                      </Button>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">No timetable uploaded yet.</p>
        )}
      </div>
    </Panel>
  );
}
