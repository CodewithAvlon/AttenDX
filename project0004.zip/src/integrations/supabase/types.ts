export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.15"
  }
  public: {
    Tables: {
      activity_log: {
        Row: {
          created_at: string
          id: number
          message: string
        }
        Insert: {
          created_at?: string
          id?: number
          message: string
        }
        Update: {
          created_at?: string
          id?: number
          message?: string
        }
        Relationships: []
      }
      attendance_records: {
        Row: {
          bench_number: number
          name: string
          recorded_at: string
          roll_number: string
          session_id: string
          status: Database["public"]["Enums"]["attendance_status"]
          verified_by_partner: boolean
        }
        Insert: {
          bench_number: number
          name: string
          recorded_at?: string
          roll_number: string
          session_id: string
          status: Database["public"]["Enums"]["attendance_status"]
          verified_by_partner?: boolean
        }
        Update: {
          bench_number?: number
          name?: string
          recorded_at?: string
          roll_number?: string
          session_id?: string
          status?: Database["public"]["Enums"]["attendance_status"]
          verified_by_partner?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "attendance_records_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      bench_layouts: {
        Row: {
          cells: Json
          class_id: string
          grid_cols: number
          grid_rows: number
          updated_at: string
        }
        Insert: {
          cells?: Json
          class_id: string
          grid_cols: number
          grid_rows: number
          updated_at?: string
        }
        Update: {
          cells?: Json
          class_id?: string
          grid_cols?: number
          grid_rows?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "bench_layouts_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: true
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
        ]
      }
      classes: {
        Row: {
          id: string
          name: string
        }
        Insert: {
          id: string
          name: string
        }
        Update: {
          id?: string
          name?: string
        }
        Relationships: []
      }
      late_entries: {
        Row: {
          applied: boolean
          class_id: string
          id: string
          marked_at: string
          marked_by: string
          name: string
          roll_number: string
          session_id: string | null
        }
        Insert: {
          applied?: boolean
          class_id: string
          id?: string
          marked_at?: string
          marked_by: string
          name: string
          roll_number: string
          session_id?: string | null
        }
        Update: {
          applied?: boolean
          class_id?: string
          id?: string
          marked_at?: string
          marked_by?: string
          name?: string
          roll_number?: string
          session_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "late_entries_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "late_entries_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string
          id: string
          login_id: string
        }
        Insert: {
          created_at?: string
          display_name: string
          id: string
          login_id: string
        }
        Update: {
          created_at?: string
          display_name?: string
          id?: string
          login_id?: string
        }
        Relationships: []
      }
      session_benches: {
        Row: {
          bench_number: number
          session_id: string
          status: Database["public"]["Enums"]["bench_status"]
        }
        Insert: {
          bench_number: number
          session_id: string
          status: Database["public"]["Enums"]["bench_status"]
        }
        Update: {
          bench_number?: number
          session_id?: string
          status?: Database["public"]["Enums"]["bench_status"]
        }
        Relationships: [
          {
            foreignKeyName: "session_benches_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      session_slots: {
        Row: {
          bench_number: number
          code: string
          entered: boolean
          failed_attempts: number
          method: Database["public"]["Enums"]["verification_method"]
          name: string
          roll_number: string
          seat: string
          session_id: string
          verified: boolean
        }
        Insert: {
          bench_number: number
          code: string
          entered?: boolean
          failed_attempts?: number
          method: Database["public"]["Enums"]["verification_method"]
          name: string
          roll_number: string
          seat: string
          session_id: string
          verified?: boolean
        }
        Update: {
          bench_number?: number
          code?: string
          entered?: boolean
          failed_attempts?: number
          method?: Database["public"]["Enums"]["verification_method"]
          name?: string
          roll_number?: string
          seat?: string
          session_id?: string
          verified?: boolean
        }
        Relationships: [
          {
            foreignKeyName: "session_slots_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      sessions: {
        Row: {
          active: boolean
          class_id: string
          class_name: string
          duration_seconds: number
          ended_at: string | null
          id: string
          started_at: string
          subject: string
          teacher_login: string
          teacher_name: string
          total_benches: number
        }
        Insert: {
          active?: boolean
          class_id: string
          class_name: string
          duration_seconds: number
          ended_at?: string | null
          id?: string
          started_at?: string
          subject: string
          teacher_login: string
          teacher_name: string
          total_benches: number
        }
        Update: {
          active?: boolean
          class_id?: string
          class_name?: string
          duration_seconds?: number
          ended_at?: string | null
          id?: string
          started_at?: string
          subject?: string
          teacher_login?: string
          teacher_name?: string
          total_benches?: number
        }
        Relationships: [
          {
            foreignKeyName: "sessions_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
        ]
      }
      staff_accounts: {
        Row: {
          display_name: string
          login_id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string | null
        }
        Insert: {
          display_name: string
          login_id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id?: string | null
        }
        Update: {
          display_name?: string
          login_id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string | null
        }
        Relationships: []
      }
      students: {
        Row: {
          bench_number: number | null
          class_id: string
          name: string
          partner_roll: string | null
          roll_number: string
          seat: string | null
          user_id: string | null
        }
        Insert: {
          bench_number?: number | null
          class_id: string
          name: string
          partner_roll?: string | null
          roll_number: string
          seat?: string | null
          user_id?: string | null
        }
        Update: {
          bench_number?: number | null
          class_id?: string
          name?: string
          partner_roll?: string | null
          roll_number?: string
          seat?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "students_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
        ]
      }
      timetable: {
        Row: {
          class_id: string
          created_at: string
          day_of_week: number
          end_time: string
          id: string
          start_time: string
          subject: string
          teacher_login: string
          updated_at: string
        }
        Insert: {
          class_id: string
          created_at?: string
          day_of_week: number
          end_time: string
          id?: string
          start_time: string
          subject: string
          teacher_login: string
          updated_at?: string
        }
        Update: {
          class_id?: string
          created_at?: string
          day_of_week?: number
          end_time?: string
          id?: string
          start_time?: string
          subject?: string
          teacher_login?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "timetable_class_id_fkey"
            columns: ["class_id"]
            isOneToOne: false
            referencedRelation: "classes"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      app_admin_home: { Args: never; Returns: Json }
      app_cancel_session: { Args: { p_session: string }; Returns: undefined }
      app_check_in: { Args: { p_bench: number }; Returns: Json }
      app_class_previous_session: {
        Args: { p_class_id: string }
        Returns: Json
      }
      app_class_today_sessions: { Args: { p_class_id: string }; Returns: Json }
      app_clear_late_entry: {
        Args: { p_class_id: string; p_roll: string }
        Returns: undefined
      }
      app_close_expired_sessions: { Args: never; Returns: number }
      app_delete_staff: { Args: { p_login: string }; Returns: undefined }
      app_delete_student: { Args: { p_roll: string }; Returns: undefined }
      app_delete_timetable_entry: { Args: { p_id: string }; Returns: undefined }
      app_end_session: { Args: { p_session: string }; Returns: undefined }
      app_extend_timer: {
        Args: { p_minutes: number; p_session: string }
        Returns: undefined
      }
      app_late_board: { Args: { p_class_id: string }; Returns: Json }
      app_local_now: { Args: never; Returns: string }
      app_mark_late: {
        Args: { p_roll: string; p_session: string }
        Returns: undefined
      }
      app_mark_late_entry: {
        Args: { p_class_id: string; p_roll: string }
        Returns: undefined
      }
      app_me: { Args: never; Returns: Json }
      app_my_history: { Args: never; Returns: Json }
      app_my_schedule: { Args: never; Returns: Json }
      app_principal_home: { Args: never; Returns: Json }
      app_save_layout: {
        Args: {
          p_cells: Json
          p_class_id: string
          p_cols: number
          p_rows: number
        }
        Returns: undefined
      }
      app_save_timetable: {
        Args: { p_entries: Json; p_replace?: boolean }
        Returns: Json
      }
      app_session_report: { Args: { p_session: string }; Returns: Json }
      app_session_view: { Args: { p_session: string }; Returns: Json }
      app_set_bench_status: {
        Args: { p_bench: number; p_session: string; p_status: string }
        Returns: undefined
      }
      app_start_session: {
        Args: {
          p_class_id: string
          p_subject: string
          p_timer_minutes?: number
          p_total_benches?: number
        }
        Returns: string
      }
      app_student_session: { Args: never; Returns: Json }
      app_teacher_home: { Args: never; Returns: Json }
      app_timetable_all: { Args: never; Returns: Json }
      app_upsert_staff: {
        Args: { p_login: string; p_name: string; p_role: string }
        Returns: undefined
      }
      app_upsert_student: {
        Args: { p_class_id: string; p_name: string; p_roll: string }
        Returns: undefined
      }
      app_verify_partner: { Args: { p_code: string }; Returns: Json }
      claim_account: { Args: { p_login_id: string }; Returns: Json }
      close_session: { Args: { p_session: string }; Returns: undefined }
      finalize_attendance: {
        Args: {
          p_bench: number
          p_name: string
          p_roll: string
          p_session: string
          p_status: Database["public"]["Enums"]["attendance_status"]
          p_verified: boolean
        }
        Returns: undefined
      }
      gen_code: { Args: never; Returns: string }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      log_activity: { Args: { p_message: string }; Returns: undefined }
      my_roll: { Args: never; Returns: string }
      recompute_bench: {
        Args: { p_bench: number; p_session: string }
        Returns: undefined
      }
      refresh_bench_occupancy: {
        Args: { p_bench: number; p_session: string }
        Returns: Database["public"]["Enums"]["bench_status"]
      }
      require_staff: {
        Args: { p_role: Database["public"]["Enums"]["app_role"] }
        Returns: {
          display_name: string
          login_id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string | null
        }
        SetofOptions: {
          from: "*"
          to: "staff_accounts"
          isOneToOne: true
          isSetofReturn: false
        }
      }
    }
    Enums: {
      app_role: "teacher" | "student" | "admin" | "principal"
      attendance_status: "PRESENT" | "LATE" | "ABSENT"
      bench_status: "PENDING" | "PARTIAL" | "PRESENT" | "SINGLE" | "EMPTY"
      verification_method: "PASSCODE" | "QR"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["teacher", "student", "admin", "principal"],
      attendance_status: ["PRESENT", "LATE", "ABSENT"],
      bench_status: ["PENDING", "PARTIAL", "PRESENT", "SINGLE", "EMPTY"],
      verification_method: ["PASSCODE", "QR"],
    },
  },
} as const
